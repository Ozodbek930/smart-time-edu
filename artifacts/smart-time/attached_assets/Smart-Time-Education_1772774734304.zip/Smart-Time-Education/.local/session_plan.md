# Objective
Add admin panel, PostgreSQL database, and SMS notifications to the IELTS prep platform. Admin can edit homepage text, add tests for all 4 skills (Speaking, Listening, Reading, Writing). Database replaces in-memory storage. SMS sent after registration and test completion via Twilio.

# Tasks

### T001: Set up PostgreSQL database
- **Blocked By**: []
- **Details**:
  - Create Replit PostgreSQL database
  - Update `shared/schema.ts` with all tables: users, speaking_tests, listening_tests, reading_tests, writing_tests, site_content (for homepage text), test_results
  - Add `role` field to users (admin/student), `isAdmin` flag
  - Add reading/writing test schemas
  - Add test_results table to track user completions
  - Add site_content table for editable homepage text
  - Push schema with `drizzle-kit push`
  - Files: `shared/schema.ts`, `server/db.ts` (create), `drizzle.config.ts`
  - Acceptance: Database provisioned, tables created, drizzle connected

### T002: Update storage layer to use PostgreSQL
- **Blocked By**: [T001]
- **Details**:
  - Rewrite `server/storage.ts` to use Drizzle ORM with PostgreSQL instead of in-memory Maps
  - Implement all CRUD operations: users, all 4 test types, site_content, test_results
  - Add admin user seeding (default admin account)
  - Update seed data to work with DB
  - Files: `server/storage.ts`, `server/seed.ts`
  - Acceptance: All existing functionality works with PostgreSQL

### T003: Set up Twilio integration for SMS
- **Blocked By**: []
- **Details**:
  - Connect Twilio via Replit integrations (connector)
  - Create SMS utility module `server/sms.ts`
  - Send SMS on: user registration (welcome message to parent phone), test completion
  - Files: `server/sms.ts` (create)
  - Acceptance: Twilio connected, SMS utility ready

### T004: Add admin API routes
- **Blocked By**: [T002]
- **Details**:
  - Add admin middleware to check `isAdmin` on user
  - Admin routes:
    - `GET/PUT /api/admin/site-content` - edit homepage text sections
    - `CRUD /api/admin/speaking-tests` - manage speaking tests
    - `CRUD /api/admin/listening-tests` - manage listening tests
    - `CRUD /api/admin/reading-tests` - manage reading tests
    - `CRUD /api/admin/writing-tests` - manage writing tests
    - `GET /api/admin/users` - list all users
    - `GET /api/admin/test-results` - view all test results
  - Update existing test routes to read from DB
  - Add SMS sending on registration and test completion
  - Files: `server/routes.ts`, `server/sms.ts`
  - Acceptance: All admin CRUD endpoints working, SMS sent on registration

### T005: Build admin panel frontend
- **Blocked By**: [T004]
- **Details**:
  - Create `/admin` page with tabbed interface:
    - Homepage Content tab: edit hero title, subtitle, about text, etc.
    - Speaking Tests tab: list/create/edit/delete speaking tests
    - Listening Tests tab: list/create/edit/delete listening tests
    - Reading Tests tab: list/create/edit/delete reading tests
    - Writing Tests tab: list/create/edit/delete writing tests
    - Users tab: view registered users
    - Test Results tab: view submitted results
  - Admin-only access (redirect non-admins)
  - Forms for creating/editing tests with all fields
  - i18n for admin labels
  - Files: `client/src/pages/admin.tsx` (create), `client/src/App.tsx`, `client/src/lib/i18n.tsx`, `client/src/components/navbar.tsx`
  - Acceptance: Admin can manage all content through the UI

### T006: Build Reading & Writing practice pages with real content
- **Blocked By**: [T002]
- **Details**:
  - Replace "Coming Soon" pages with real practice pages
  - Reading page: show passages with questions (multiple choice, fill-in-blank)
  - Writing page: show writing tasks (Task 1 & Task 2)
  - Both pages fetch from database
  - Add test submission and result tracking
  - Files: `client/src/pages/reading.tsx`, `client/src/pages/writing.tsx`
  - Acceptance: Reading and Writing pages functional with DB content

### T007: Add test result tracking and SMS on completion
- **Blocked By**: [T004, T006]
- **Details**:
  - Add ability for students to submit answers/complete tests
  - Store results in test_results table
  - Send SMS to parent phone on test completion
  - Show results on dashboard
  - Files: `server/routes.ts`, `client/src/pages/dashboard.tsx`, `client/src/pages/speaking.tsx`, `client/src/pages/listening.tsx`
  - Acceptance: Results tracked, SMS sent on completion, dashboard shows progress

### T008: Update i18n and replit.md
- **Blocked By**: [T005, T006, T007]
- **Details**:
  - Add all new translation keys for admin panel, reading, writing pages
  - Update replit.md with new architecture
  - Files: `client/src/lib/i18n.tsx`, `replit.md`
  - Acceptance: All text translated in EN/RU/UZ, docs updated
