# SmartCEFR Mock Exam

A CEFR B2 English proficiency mock exam platform with Listening, Reading, and Writing sections.

## Architecture

- **Frontend**: React + TypeScript + Tailwind CSS + shadcn/ui
- **Backend**: Express.js (minimal — all exam data stored in localStorage)
- **Routing**: Wouter
- **Language**: i18n via custom `client/src/i18n/index.ts`

## Pages

- `/` — Registration page (shown first on every visit)
- `/home` — Home/landing page with exam overview
- `/exam` — Full exam interface with timer, notes, highlights
- `/admin` — Admin panel for managing questions (password: admin123)

## Key Files

- `client/src/data/examData.ts` — Default exam content (English)
- `client/src/data/adminExamData.ts` — localStorage helpers, multilingual data conversion
- `client/src/i18n/index.ts` — All UI translations (EN/RU/UZ)
- `client/src/contexts/LanguageContext.tsx` — Language state and hook
- `client/src/components/LanguageSwitcher.tsx` — Language dropdown component
- `client/src/pages/Register.tsx` — Registration form
- `client/src/pages/Home.tsx` — Landing page
- `client/src/pages/Exam.tsx` — Main exam interface
- `client/src/pages/Admin.tsx` — Admin panel

## Languages

3 languages supported (default: English):
- 🇬🇧 English (en)
- 🇷🇺 Русский (ru)
- 🇺🇿 O'zbekcha (uz)

Language switcher available on all pages. Preference saved to localStorage (`cefr_lang`).

## Admin Panel

URL: `/admin`
Password: `admin123` (default)

Features:
- Login with password
- Browse sections/parts in left sidebar
- Edit part instructions/context/text in all 3 languages
- Add/edit/delete questions with multilingual prompts and options
- Questions support all types: MCQ, gap-fill, matching-dropdown, one-word-fill, textarea
- Save all changes (persisted to localStorage `cefr_admin_data`)
- Reset to defaults
- Language fill indicators (EN/RU/UZ badges) per question

## Exam Structure

### Listening (45 min)
- Part 1 (Q1–8): Multiple choice replies
- Part 2 (Q9–14): Gap fill
- Part 3 (Q15–19): Matching speakers to reasons (A–H)
- Part 4 (Q20–24): Map-based matching (A–H)
- Part 5 (Q25–30): Multiple choice extracts
- Part 6 (Q31–35): One word gap fill

### Reading (60 min)
- Part 1 (Q1–6): Gap fill from passage (Jack Calder)
- Part 2 (Q7–14): Text-to-statement matching (restaurants)
- Part 3 (Q15–20): Paragraph-to-heading matching (UK transport)
- Part 4 (Q21–29): MCQ + True/False/No info (Mandarin in California)
- Part 5 (Q30–35): Mixed questions (Hyperpolyglots)

### Writing (60 min)
- Task 1.1: Short email to friend (~50 words)
- Task 1.2: Formal email to coordinator (120–150 words)
- Task 2: Online discussion post (180–200 words)

## Storage Keys (localStorage)

- `cefr_student` — Registered student info (JSON)
- `cefr_lang` — Current language preference
- `cefr_admin_data` — Custom/edited exam data (JSON)
- `cefr_admin_auth` — Admin session flag
