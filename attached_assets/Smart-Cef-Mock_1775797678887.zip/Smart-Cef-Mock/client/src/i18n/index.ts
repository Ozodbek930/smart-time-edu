export type Lang = "en" | "ru" | "uz";

export const LANG_KEY = "cefr_lang";

export const langNames: Record<Lang, string> = {
  en: "English",
  ru: "Русский",
  uz: "O'zbekcha",
};

export const langFlags: Record<Lang, string> = {
  en: "🇬🇧",
  ru: "🇷🇺",
  uz: "🇺🇿",
};

type T = Record<string, Record<Lang, string>>;

export const t: T = {
  /* ── App / Header ─────────────────────────────────────────── */
  appName: { en: "SmartCEFR", ru: "SmartCEFR", uz: "SmartCEFR" },
  appSubtitle: { en: "Mock Exam", ru: "Пробный экзамен", uz: "Sinov imtihon" },
  levelBadge: { en: "B2 Level", ru: "Уровень B2", uz: "B2 darajasi" },

  /* ── Register ─────────────────────────────────────────────── */
  register: { en: "Registration", ru: "Регистрация", uz: "Ro'yxatdan o'tish" },
  registerSubtitle: {
    en: "Fill in your details before starting the exam",
    ru: "Заполните данные перед началом экзамена",
    uz: "Imtihonni boshlashdan oldin ma'lumotlaringizni kiriting",
  },
  fullName: { en: "Full Name", ru: "Полное имя", uz: "To'liq ism" },
  fullNamePlaceholder: {
    en: "John Smith",
    ru: "Иванов Иван Иванович",
    uz: "Aliyev Ali Alievich",
  },
  email: { en: "Email Address", ru: "Email адрес", uz: "Email manzil" },
  emailPlaceholder: {
    en: "john@example.com",
    ru: "ivan@example.com",
    uz: "ali@example.com",
  },
  school: {
    en: "School / Institution",
    ru: "Школа / Учебное заведение",
    uz: "Maktab / Ta'lim muassasasi",
  },
  schoolPlaceholder: {
    en: "School No. 1",
    ru: "Школа №1 / МГУ",
    uz: "1-maktab / TDPU",
  },
  studentId: {
    en: "Student ID / Class",
    ru: "ID студента / Номер группы",
    uz: "Talaba ID / Guruh raqami",
  },
  studentIdPlaceholder: {
    en: "STU-2024-001 / Class 11A",
    ru: "STU-2024-001 / Группа 11А",
    uz: "STU-2024-001 / 11-A sinf",
  },
  startExam: { en: "Start Exam", ru: "Начать экзамен", uz: "Imtihonni boshlash" },
  privacyNote: {
    en: "Your data is saved only in your browser and is not shared with third parties.",
    ru: "Данные сохраняются только в вашем браузере и не передаются третьим лицам.",
    uz: "Ma'lumotlaringiz faqat brauzeringizda saqlanadi va uchinchi shaxslarga uzatilmaydi.",
  },

  /* ── Validation ───────────────────────────────────────────── */
  errFullName: {
    en: "Please enter your full name",
    ru: "Введите ваше полное имя",
    uz: "To'liq ismingizni kiriting",
  },
  errEmail: {
    en: "Please enter your email",
    ru: "Введите email",
    uz: "Email kiriting",
  },
  errEmailInvalid: {
    en: "Invalid email address",
    ru: "Некорректный email адрес",
    uz: "Noto'g'ri email manzil",
  },
  errSchool: {
    en: "Please enter your school or institution",
    ru: "Введите название школы / учебного заведения",
    uz: "Maktab yoki ta'lim muassasasini kiriting",
  },
  errStudentId: {
    en: "Please enter your student ID or class",
    ru: "Введите ID студента или номер группы",
    uz: "Talaba ID yoki guruh raqamini kiriting",
  },

  /* ── Home ─────────────────────────────────────────────────── */
  practiceBadge: {
    en: "CEFR B2 Practice Examination",
    ru: "Пробный экзамен CEFR B2",
    uz: "CEFR B2 Sinov imtihoni",
  },
  heroTitle1: {
    en: "Prepare for Your",
    ru: "Подготовьтесь к своему",
    uz: "Imtihonizga",
  },
  heroTitle2: {
    en: "CEFR B2 Exam",
    ru: "Экзамену CEFR B2",
    uz: "CEFR B2 imtihoni",
  },
  heroDesc: {
    en: "A complete mock exam with Listening, Reading, and Writing sections — timed and formatted exactly like the real test.",
    ru: "Полный пробный экзамен с разделами Аудирование, Чтение и Письмо — с таймером и форматом, как на реальном тесте.",
    uz: "Tinglash, O'qish va Yozish bo'limlari bilan to'liq sinov imtihon — vaqt chegarasi va haqiqiy test formati bilan.",
  },
  listening: { en: "Listening", ru: "Аудирование", uz: "Tinglash" },
  reading: { en: "Reading", ru: "Чтение", uz: "O'qish" },
  writing: { en: "Writing", ru: "Письмо", uz: "Yozish" },
  listeningDesc: {
    en: "6 parts · 35 questions covering multiple choice, gap-fill, and matching tasks.",
    ru: "6 частей · 35 вопросов: множественный выбор, заполнение пропусков и сопоставление.",
    uz: "6 qism · 35 savol: ko'p tanlov, bo'sh joylarni to'ldirish va moslashtirish.",
  },
  readingDesc: {
    en: "5 parts · 35 questions including text matching, gap-fill, and comprehension.",
    ru: "5 частей · 35 вопросов: сопоставление текстов, заполнение пропусков и понимание.",
    uz: "5 qism · 35 savol: matn moslash, bo'sh joylarni to'ldirish va tushunish.",
  },
  writingDesc: {
    en: "3 tasks · Short email, formal email, and an online discussion post.",
    ru: "3 задания · Короткое письмо, официальное письмо и пост в онлайн-дискуссии.",
    uz: "3 topshiriq · Qisqa xat, rasmiy xat va onlayn muhokama posti.",
  },
  minutes: { en: "minutes", ru: "минут", uz: "daqiqa" },
  beforeYouBegin: {
    en: "Before you begin",
    ru: "Перед началом",
    uz: "Boshlashdan oldin",
  },
  instructions: {
    en: [
      "Read all instructions carefully before answering each part.",
      "The timer counts down — manage your time wisely across sections.",
      "Use the Notes button to jot down thoughts while working.",
      "Highlight text to mark important passages for reference.",
      "You can navigate between parts freely within a section.",
      "Download your Writing responses at the end of the exam.",
    ] as unknown as string,
    ru: [
      "Внимательно прочитайте все инструкции перед ответом на каждую часть.",
      "Таймер ведёт обратный отсчёт — управляйте временем грамотно.",
      "Используйте кнопку «Заметки» для записей во время работы.",
      "Выделяйте текст, чтобы отмечать важные отрывки.",
      "Вы можете свободно переходить между частями раздела.",
      "Скачайте ответы к письменным заданиям в конце экзамена.",
    ] as unknown as string,
    uz: [
      "Har bir qismga javob berishdan oldin barcha ko'rsatmalarni diqqat bilan o'qing.",
      "Taymer orqaga hisoblaydi — vaqtingizni to'g'ri boshqaring.",
      "Ishlash jarayonida fikrlarni yozib qo'yish uchun 'Eslatmalar' tugmasini ishlating.",
      "Muhim parchalarni belgilash uchun matnni ajratib ko'rsating.",
      "Bo'lim ichida qismlar o'rtasida erkin harakat qilishingiz mumkin.",
      "Imtihon oxirida yozma javoblaringizni yuklab oling.",
    ] as unknown as string,
  },
  startMockExam: {
    en: "Start Mock Exam",
    ru: "Начать пробный экзамен",
    uz: "Sinov imtihonini boshlash",
  },
  examDuration: {
    en: "All sections combined — approx. 2 hours 45 minutes",
    ru: "Все разделы вместе — около 2 часов 45 минут",
    uz: "Barcha bo'limlar birgalikda — taxminan 2 soat 45 daqiqa",
  },

  /* ── Exam ─────────────────────────────────────────────────── */
  parts: { en: "Parts:", ru: "Части:", uz: "Qismlar:" },
  highlight: { en: "Highlight", ru: "Выделить", uz: "Belgilash" },
  clear: { en: "Clear", ru: "Очистить", uz: "Tozalash" },
  notes: { en: "Notes", ru: "Заметки", uz: "Eslatmalar" },
  submit: { en: "Submit", ru: "Сдать", uz: "Topshirish" },
  highlightMode: {
    en: "Highlight mode — select text to highlight",
    ru: "Режим выделения — выберите текст для выделения",
    uz: "Belgilash rejimi — matnni belgilash uchun tanlang",
  },
  clearAll: { en: "Clear all", ru: "Очистить всё", uz: "Hammasini tozalash" },
  options: { en: "Options", ru: "Варианты", uz: "Variantlar" },
  context: { en: "Context", ru: "Контекст", uz: "Kontekst" },
  previous: { en: "Previous", ru: "Назад", uz: "Oldingi" },
  next: { en: "Next", ru: "Далее", uz: "Keyingi" },
  total: { en: "Total:", ru: "Итого:", uz: "Jami:" },
  wordsTarget: {
    en: "Target:",
    ru: "Цель:",
    uz: "Maqsad:",
  },
  words: { en: "words", ru: "слов", uz: "so'z" },
  yourResponse: {
    en: "Your response",
    ru: "Ваш ответ",
    uz: "Sizning javobingiz",
  },
  select: { en: "Select", ru: "Выбрать", uz: "Tanlash" },
  timerWarning: {
    en: "Less than 5 minutes remaining!",
    ru: "Осталось менее 5 минут!",
    uz: "5 daqiqadan kam vaqt qoldi!",
  },
  writeNotes: {
    en: "Write your notes here...",
    ru: "Напишите ваши заметки здесь...",
    uz: "Bu yerga eslatmalaringizni yozing...",
  },

  /* ── Results ─────────────────────────────────────────────────── */
  examSubmitted: {
    en: "Exam Submitted!",
    ru: "Экзамен сдан!",
    uz: "Imtihon topshirildi!",
  },
  answeredOf: {
    en: "You answered",
    ru: "Вы ответили на",
    uz: "Siz javob berdingiz",
  },
  outOf: { en: "out of", ru: "из", uz: "dan" },
  questions2: { en: "questions.", ru: "вопросов.", uz: "savol." },
  downloadNote: {
    en: "Download your responses or return to the home page.",
    ru: "Скачайте ответы или вернитесь на главную страницу.",
    uz: "Javoblaringizni yuklab oling yoki bosh sahifaga qayting.",
  },
  downloadResults: {
    en: "Download Results (.txt)",
    ru: "Скачать результаты (.txt)",
    uz: "Natijalarni yuklab olish (.txt)",
  },
  downloadWriting: {
    en: "Download Writing (.txt)",
    ru: "Скачать письмо (.txt)",
    uz: "Yozishni yuklab olish (.txt)",
  },
  backToHome: { en: "Back to Home", ru: "На главную", uz: "Bosh sahifaga" },
  logout: { en: "Logout", ru: "Выйти", uz: "Chiqish" },

  /* ── Admin ─────────────────────────────────────────────────── */
  admin: { en: "Admin Panel", ru: "Панель администратора", uz: "Admin paneli" },
  adminLogin: {
    en: "Admin Login",
    ru: "Вход для администратора",
    uz: "Admin kirish",
  },
  password: { en: "Password", ru: "Пароль", uz: "Parol" },
  loginBtn: { en: "Login", ru: "Войти", uz: "Kirish" },
  wrongPassword: {
    en: "Incorrect password",
    ru: "Неверный пароль",
    uz: "Noto'g'ri parol",
  },
  addQuestion: {
    en: "Add Question",
    ru: "Добавить вопрос",
    uz: "Savol qo'shish",
  },
  editQuestion: {
    en: "Edit Question",
    ru: "Редактировать вопрос",
    uz: "Savolni tahrirlash",
  },
  deleteQuestion: {
    en: "Delete",
    ru: "Удалить",
    uz: "O'chirish",
  },
  save: { en: "Save", ru: "Сохранить", uz: "Saqlash" },
  cancel: { en: "Cancel", ru: "Отмена", uz: "Bekor qilish" },
  resetToDefaults: {
    en: "Reset to Defaults",
    ru: "Сбросить к исходным",
    uz: "Standartga qaytarish",
  },
  questionType: {
    en: "Question Type",
    ru: "Тип вопроса",
    uz: "Savol turi",
  },
  prompt: { en: "Prompt", ru: "Вопрос/подсказка", uz: "Savol/ko'rsatma" },
  option: { en: "Option", ru: "Вариант", uz: "Variant" },
  addOption: {
    en: "Add Option",
    ru: "Добавить вариант",
    uz: "Variant qo'shish",
  },
  instructions2: {
    en: "Instructions",
    ru: "Инструкции",
    uz: "Ko'rsatmalar",
  },
  partTitle: { en: "Part Title", ru: "Название части", uz: "Qism nomi" },
  unsavedChanges: {
    en: "You have unsaved changes",
    ru: "У вас есть несохранённые изменения",
    uz: "Saqlanmagan o'zgarishlar bor",
  },
  savedSuccess: {
    en: "Saved successfully!",
    ru: "Успешно сохранено!",
    uz: "Muvaffaqiyatli saqlandi!",
  },
  confirmDelete: {
    en: "Are you sure you want to delete this question?",
    ru: "Вы уверены, что хотите удалить этот вопрос?",
    uz: "Bu savolni o'chirmoqchimisiz?",
  },
  addPart: {
    en: "Add Part",
    ru: "Добавить часть",
    uz: "Qism qo'shish",
  },
  deletePart: {
    en: "Delete Part",
    ru: "Удалить часть",
    uz: "Qismni o'chirish",
  },
  noQuestions: {
    en: "No questions in this part.",
    ru: "В этой части нет вопросов.",
    uz: "Bu qismda savollar yo'q.",
  },
};

export function translate(key: string, lang: Lang): string {
  const entry = t[key];
  if (!entry) return key;
  return (entry[lang] as string) ?? (entry["en"] as string) ?? key;
}
