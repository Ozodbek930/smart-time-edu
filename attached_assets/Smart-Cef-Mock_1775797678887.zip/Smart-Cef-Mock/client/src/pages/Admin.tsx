import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  BookOpen, Lock, Eye, EyeOff, ChevronRight, ChevronDown, Plus, Trash2,
  Save, RotateCcw, LogOut, Settings, AlertTriangle, CheckCircle, Edit2,
  ChevronLeft, Headphones, PenLine, X, GripVertical,
} from "lucide-react";
import {
  loadAdminData, saveAdminData, resetAdminData, buildDefaultAdminData,
  ADMIN_PASSWORD, ADMIN_AUTH_KEY, ADMIN_DATA_KEY, generateId,
  type AdminData, type AdminSection, type AdminPart, type AdminQuestion, type AdminOption, type MultiLang,
} from "@/data/adminExamData";
import type { QuestionType } from "@/data/examData";

type Lang = "en" | "ru" | "uz";
const LANG_TABS: { id: Lang; label: string; flag: string }[] = [
  { id: "en", label: "English", flag: "🇬🇧" },
  { id: "ru", label: "Русский", flag: "🇷🇺" },
  { id: "uz", label: "O'zbekcha", flag: "🇺🇿" },
];

const QUESTION_TYPES: QuestionType[] = ["mcq", "gap-fill", "matching-dropdown", "one-word-fill", "textarea"];

function mlText(v: MultiLang | undefined, lang: Lang) { return v?.[lang] ?? ""; }
function setMl(v: MultiLang, lang: Lang, val: string): MultiLang { return { ...v, [lang]: val }; }
function emptyMl(): MultiLang { return { en: "", ru: "", uz: "" }; }

/* ── Login screen ─────────────────────────────────────────────────────────── */
function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const [pw, setPw] = useState("");
  const [show, setShow] = useState(false);
  const [err, setErr] = useState(false);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (pw === ADMIN_PASSWORD) {
      localStorage.setItem(ADMIN_AUTH_KEY, "1");
      onLogin();
    } else {
      setErr(true);
      setTimeout(() => setErr(false), 2000);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="inline-flex w-14 h-14 bg-white/10 rounded-2xl items-center justify-center mb-4">
            <Settings className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
          <p className="text-slate-400 text-sm mt-1">SmartCEFR Question Editor</p>
        </div>
        <form onSubmit={submit} className="bg-white rounded-2xl p-7 shadow-2xl">
          <label className="block text-sm font-medium text-slate-700 mb-2">
            Password
          </label>
          <div className="relative mb-5">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              data-testid="input-admin-password"
              type={show ? "text" : "password"}
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              placeholder="Enter admin password"
              className={`w-full pl-10 pr-10 py-2.5 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all ${
                err ? "border-red-400 bg-red-50 animate-pulse" : "border-slate-300"
              }`}
            />
            <button type="button" onClick={() => setShow(s => !s)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
              {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {err && (
            <div className="flex items-center gap-2 text-red-500 text-sm mb-3">
              <AlertTriangle className="w-4 h-4" /> Incorrect password
            </div>
          )}
          <button data-testid="button-admin-login" type="submit"
            className="w-full bg-slate-800 hover:bg-slate-900 text-white font-semibold py-2.5 rounded-xl transition-colors">
            Login
          </button>
        </form>
      </div>
    </div>
  );
}

/* ── Question edit modal ─────────────────────────────────────────────────── */
function QuestionModal({
  q, onSave, onClose,
}: {
  q: AdminQuestion | null; onSave: (q: AdminQuestion) => void; onClose: () => void;
}) {
  const isNew = !q;
  const [data, setData] = useState<AdminQuestion>(
    q ?? {
      id: generateId("q"), number: 1, type: "mcq",
      prompt: emptyMl(),
      options: [
        { label: "A", text: emptyMl() },
        { label: "B", text: emptyMl() },
        { label: "C", text: emptyMl() },
      ],
    }
  );
  const [activeLang, setActiveLang] = useState<Lang>("en");

  function updatePrompt(lang: Lang, val: string) {
    setData(d => ({ ...d, prompt: setMl(d.prompt, lang, val) }));
  }
  function updateOptionText(i: number, lang: Lang, val: string) {
    setData(d => {
      const opts = [...(d.options ?? [])];
      opts[i] = { ...opts[i], text: setMl(opts[i].text, lang, val) };
      return { ...d, options: opts };
    });
  }
  function addOption() {
    const labels = "ABCDEFGHIJ";
    setData(d => ({
      ...d,
      options: [...(d.options ?? []), { label: labels[(d.options?.length ?? 0) % 10], text: emptyMl() }],
    }));
  }
  function removeOption(i: number) {
    setData(d => ({ ...d, options: (d.options ?? []).filter((_, idx) => idx !== i) }));
  }

  const needsOptions = data.type === "mcq";

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-auto"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h3 className="font-bold text-slate-800 text-lg">
            {isNew ? "Add Question" : "Edit Question"}
          </h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-6 space-y-5">
          {/* Type + Number */}
          <div className="flex gap-4">
            <div className="flex-1">
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">Question #</label>
              <input type="number" value={data.number} min={1}
                onChange={e => setData(d => ({ ...d, number: +e.target.value }))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div className="flex-1">
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">Question Type</label>
              <select value={data.type}
                onChange={e => setData(d => ({ ...d, type: e.target.value as QuestionType }))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
                {QUESTION_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
          </div>

          {/* Language tabs */}
          <div>
            <div className="flex gap-1 bg-slate-100 p-1 rounded-xl mb-4">
              {LANG_TABS.map(lt => (
                <button key={lt.id} onClick={() => setActiveLang(lt.id)}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    activeLang === lt.id ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"
                  }`}>
                  <span>{lt.flag}</span> {lt.label}
                </button>
              ))}
            </div>

            {/* Prompt */}
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">
              Prompt / Question Text ({activeLang.toUpperCase()})
            </label>
            <textarea value={mlText(data.prompt, activeLang)}
              onChange={e => updatePrompt(activeLang, e.target.value)}
              rows={3}
              placeholder={`Enter question prompt in ${LANG_TABS.find(l => l.id === activeLang)?.label}`}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
          </div>

          {/* Options (MCQ) */}
          {needsOptions && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
                  Options ({activeLang.toUpperCase()})
                </label>
                <button onClick={addOption}
                  className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-700 font-medium">
                  <Plus className="w-3.5 h-3.5" /> Add Option
                </button>
              </div>
              <div className="space-y-2">
                {(data.options ?? []).map((opt, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="w-7 h-7 bg-slate-100 rounded-full flex items-center justify-center text-xs font-bold text-slate-600 flex-shrink-0">
                      {opt.label}
                    </span>
                    <input value={mlText(opt.text, activeLang)}
                      onChange={e => updateOptionText(i, activeLang, e.target.value)}
                      placeholder={`Option ${opt.label} text`}
                      className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    <button onClick={() => removeOption(i)}
                      className="text-slate-400 hover:text-red-500 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Word limit for textarea */}
          {data.type === "textarea" && (
            <div>
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">Word Limit (e.g. "120–150")</label>
              <input value={data.wordLimit ?? ""} onChange={e => setData(d => ({ ...d, wordLimit: e.target.value }))}
                placeholder="e.g. 120–150 words"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
          )}
        </div>
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-100 bg-slate-50 rounded-b-2xl">
          <button onClick={onClose}
            className="px-5 py-2 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-100 transition-colors">
            Cancel
          </button>
          <button data-testid="button-save-question" onClick={() => onSave(data)}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors">
            <Save className="w-4 h-4" /> Save Question
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── Part instructions edit modal ──────────────────────────────────────────── */
function PartModal({ part, onSave, onClose }: { part: AdminPart; onSave: (p: AdminPart) => void; onClose: () => void; }) {
  const [data, setData] = useState<AdminPart>(JSON.parse(JSON.stringify(part)));
  const [activeLang, setActiveLang] = useState<Lang>("en");

  function updateField(field: "instructions" | "context" | "text", lang: Lang, val: string) {
    setData(d => {
      const cur = d[field] as MultiLang | undefined ?? emptyMl();
      return { ...d, [field]: setMl(cur, lang, val) };
    });
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-auto"
        onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
          <h3 className="font-bold text-slate-800 text-lg">Edit Part: {data.title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5" /></button>
        </div>
        <div className="p-6 space-y-5">
          {/* Title & Range */}
          <div className="flex gap-4">
            <div className="flex-1">
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">Part Title</label>
              <input value={data.title} onChange={e => setData(d => ({ ...d, title: e.target.value }))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div className="w-32">
              <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">Range</label>
              <input value={data.range} onChange={e => setData(d => ({ ...d, range: e.target.value }))}
                placeholder="e.g. 1–8"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>

          {/* Language tabs */}
          <div className="flex gap-1 bg-slate-100 p-1 rounded-xl">
            {LANG_TABS.map(lt => (
              <button key={lt.id} onClick={() => setActiveLang(lt.id)}
                className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  activeLang === lt.id ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"
                }`}>
                <span>{lt.flag}</span> {lt.label}
              </button>
            ))}
          </div>

          {/* Instructions */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">
              Instructions ({activeLang.toUpperCase()})
            </label>
            <textarea value={mlText(data.instructions, activeLang)}
              onChange={e => updateField("instructions", activeLang, e.target.value)}
              rows={3} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
          </div>

          {/* Context */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">
              Context / Heading ({activeLang.toUpperCase()}) <span className="text-slate-400 font-normal normal-case">(optional)</span>
            </label>
            <textarea value={mlText(data.context, activeLang)}
              onChange={e => updateField("context", activeLang, e.target.value)}
              rows={2} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
          </div>

          {/* Passage Text */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1.5">
              Text Passage ({activeLang.toUpperCase()}) <span className="text-slate-400 font-normal normal-case">(optional)</span>
            </label>
            <textarea value={mlText(data.text, activeLang)}
              onChange={e => updateField("text", activeLang, e.target.value)}
              rows={5} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
          </div>
        </div>
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-slate-100 bg-slate-50 rounded-b-2xl">
          <button onClick={onClose} className="px-5 py-2 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-100 transition-colors">Cancel</button>
          <button onClick={() => onSave(data)}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors">
            <Save className="w-4 h-4" /> Save Part
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── Main Admin Panel ──────────────────────────────────────────────────────── */
export default function Admin() {
  const [, setLocation] = useLocation();
  const [authed, setAuthed] = useState(() => !!localStorage.getItem(ADMIN_AUTH_KEY));
  const [data, setData] = useState<AdminData>(() => loadAdminData());
  const [activeSec, setActiveSec] = useState(0);
  const [activePart, setActivePart] = useState(0);
  const [editingQ, setEditingQ] = useState<AdminQuestion | null | "new">(null);
  const [editingPart, setEditingPart] = useState<AdminPart | null>(null);
  const [saved, setSaved] = useState(false);
  const [dirty, setDirty] = useState(false);

  const section = data[activeSec];
  const part = section?.parts[activePart];

  function markDirty() { setDirty(true); setSaved(false); }

  function handleSave() {
    saveAdminData(data);
    setDirty(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  function handleReset() {
    if (!confirm("Reset all questions to defaults? This cannot be undone.")) return;
    const def = buildDefaultAdminData();
    setData(def);
    saveAdminData(def);
    setDirty(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  function handleLogout() {
    localStorage.removeItem(ADMIN_AUTH_KEY);
    setLocation("/");
  }

  /* Question CRUD */
  function saveQuestion(q: AdminQuestion) {
    setData(d => {
      const newData = JSON.parse(JSON.stringify(d)) as AdminData;
      const qs = newData[activeSec].parts[activePart].questions;
      const idx = qs.findIndex(x => x.id === q.id);
      if (idx >= 0) qs[idx] = q;
      else qs.push(q);
      return newData;
    });
    setEditingQ(null);
    markDirty();
  }

  function deleteQuestion(qId: string) {
    if (!confirm("Delete this question?")) return;
    setData(d => {
      const newData = JSON.parse(JSON.stringify(d)) as AdminData;
      newData[activeSec].parts[activePart].questions =
        newData[activeSec].parts[activePart].questions.filter(q => q.id !== qId);
      return newData;
    });
    markDirty();
  }

  /* Part CRUD */
  function savePart(p: AdminPart) {
    setData(d => {
      const newData = JSON.parse(JSON.stringify(d)) as AdminData;
      newData[activeSec].parts[activePart] = p;
      return newData;
    });
    setEditingPart(null);
    markDirty();
  }

  function addNewPart() {
    const newPart: AdminPart = {
      id: generateId("part"),
      title: `Part ${section.parts.length + 1}`,
      range: "1–5",
      instructions: { en: "Instructions here...", ru: "", uz: "" },
      questions: [],
    };
    setData(d => {
      const newData = JSON.parse(JSON.stringify(d)) as AdminData;
      newData[activeSec].parts.push(newPart);
      return newData;
    });
    setActivePart(section.parts.length);
    markDirty();
  }

  function deletePart(partIdx: number) {
    if (!confirm("Delete this part and all its questions?")) return;
    setData(d => {
      const newData = JSON.parse(JSON.stringify(d)) as AdminData;
      newData[activeSec].parts.splice(partIdx, 1);
      return newData;
    });
    setActivePart(Math.max(0, activePart - 1));
    markDirty();
  }

  if (!authed) return <LoginScreen onLogin={() => setAuthed(true)} />;

  function SectionIcon({ id }: { id: string }) {
    if (id === "listening") return <Headphones className="w-4 h-4" />;
    if (id === "reading") return <BookOpen className="w-4 h-4" />;
    return <PenLine className="w-4 h-4" />;
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      {/* Top bar */}
      <header className="bg-slate-900 text-white h-14 flex items-center px-5 gap-4 sticky top-0 z-30">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 bg-blue-500 rounded-lg flex items-center justify-center">
            <Settings className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-sm">SmartCEFR Admin</span>
        </div>
        <div className="flex-1" />

        {/* Status */}
        {saved && (
          <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-medium animate-fade-in">
            <CheckCircle className="w-4 h-4" /> Saved!
          </div>
        )}
        {dirty && !saved && (
          <div className="flex items-center gap-1.5 text-amber-400 text-xs font-medium">
            <AlertTriangle className="w-4 h-4" /> Unsaved changes
          </div>
        )}

        <button onClick={handleReset}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-medium transition-colors">
          <RotateCcw className="w-3.5 h-3.5" /> Reset
        </button>
        <button data-testid="button-admin-save" onClick={handleSave}
          className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-blue-500 hover:bg-blue-600 text-white text-xs font-bold transition-colors">
          <Save className="w-3.5 h-3.5" /> Save All
        </button>
        <button onClick={() => setLocation("/home")}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-medium transition-colors">
          <BookOpen className="w-3.5 h-3.5" /> View Site
        </button>
        <button onClick={handleLogout}
          className="text-slate-400 hover:text-white transition-colors p-1.5">
          <LogOut className="w-4 h-4" />
        </button>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-56 bg-white border-r border-slate-200 flex flex-col overflow-y-auto flex-shrink-0">
          {data.map((sec, si) => (
            <div key={sec.id}>
              {/* Section header */}
              <button
                onClick={() => { setActiveSec(si); setActivePart(0); }}
                className={`w-full flex items-center gap-2 px-4 py-3 text-sm font-semibold transition-colors border-b border-slate-100 ${
                  activeSec === si ? "bg-blue-50 text-blue-700" : "text-slate-700 hover:bg-slate-50"
                }`}>
                <SectionIcon id={sec.id} />
                {sec.title}
              </button>
              {/* Parts */}
              {activeSec === si && sec.parts.map((p, pi) => (
                <button key={p.id} onClick={() => setActivePart(pi)}
                  className={`w-full flex items-center gap-2 px-5 py-2 text-xs font-medium transition-colors ${
                    activePart === pi ? "bg-blue-600 text-white" : "text-slate-600 hover:bg-slate-50"
                  }`}>
                  <ChevronRight className="w-3 h-3 flex-shrink-0" />
                  <span className="truncate">{p.title}</span>
                  <span className={`ml-auto text-[10px] font-bold px-1.5 py-0.5 rounded-full flex-shrink-0 ${
                    activePart === pi ? "bg-blue-500 text-white" : "bg-slate-100 text-slate-500"
                  }`}>{p.questions.length}</span>
                </button>
              ))}
              {activeSec === si && (
                <button onClick={addNewPart}
                  className="w-full flex items-center gap-2 px-5 py-2 text-xs text-blue-600 hover:bg-blue-50 transition-colors font-medium border-b border-slate-100">
                  <Plus className="w-3 h-3" /> Add Part
                </button>
              )}
            </div>
          ))}
        </aside>

        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-6">
          {part ? (
            <>
              {/* Part header */}
              <div className="flex items-start justify-between mb-6">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
                    <span>{section.title}</span>
                    <ChevronRight className="w-3 h-3" />
                    <span className="text-blue-600 font-medium">{part.title}</span>
                    <span>({part.range})</span>
                  </div>
                  <h2 className="text-xl font-bold text-slate-800">{part.title}</h2>
                  <p className="text-slate-500 text-sm mt-1 max-w-lg">
                    {part.instructions.en.slice(0, 100)}{part.instructions.en.length > 100 ? "…" : ""}
                  </p>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <button onClick={() => setEditingPart(part)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 text-sm font-medium transition-colors">
                    <Edit2 className="w-3.5 h-3.5" /> Edit Part
                  </button>
                  <button onClick={() => deletePart(activePart)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-red-200 bg-red-50 hover:bg-red-100 text-red-600 text-sm font-medium transition-colors">
                    <Trash2 className="w-3.5 h-3.5" /> Delete Part
                  </button>
                </div>
              </div>

              {/* Questions table */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
                  <h3 className="font-semibold text-slate-700">
                    Questions <span className="text-slate-400 font-normal">({part.questions.length})</span>
                  </h3>
                  <button data-testid="button-add-question" onClick={() => setEditingQ("new")}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors">
                    <Plus className="w-4 h-4" /> Add Question
                  </button>
                </div>

                {part.questions.length === 0 ? (
                  <div className="py-16 text-center text-slate-400">
                    <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-3">
                      <BookOpen className="w-6 h-6 text-slate-300" />
                    </div>
                    <p className="font-medium text-slate-500">No questions yet</p>
                    <p className="text-sm mt-1">Click "Add Question" to create one</p>
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {part.questions.map((q, qi) => (
                      <div key={q.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-slate-50 transition-colors group">
                        <GripVertical className="w-4 h-4 text-slate-300" />
                        <span className="w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">
                          {q.number}
                        </span>
                        <div className="flex-1 min-w-0">
                          <p className="text-slate-800 text-sm font-medium truncate">
                            {q.prompt.en || "(no prompt)"}
                          </p>
                          <div className="flex items-center gap-3 mt-0.5">
                            <span className="text-xs text-slate-400">{q.type}</span>
                            {q.options && <span className="text-xs text-slate-400">{q.options.length} options</span>}
                            {/* Language fill indicators */}
                            <div className="flex items-center gap-1">
                              {(["en","ru","uz"] as Lang[]).map(l => (
                                <span key={l} className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
                                  q.prompt[l] ? "bg-emerald-100 text-emerald-600" : "bg-slate-100 text-slate-400"
                                }`}>{l.toUpperCase()}</span>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => setEditingQ(q)}
                            className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 text-xs font-medium hover:bg-slate-100 transition-colors">
                            <Edit2 className="w-3 h-3" /> Edit
                          </button>
                          <button onClick={() => deleteQuestion(q.id)}
                            className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-red-100 text-red-500 text-xs font-medium hover:bg-red-50 transition-colors">
                            <Trash2 className="w-3 h-3" /> Delete
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-64 text-slate-400">
              Select a section and part from the sidebar
            </div>
          )}
        </main>
      </div>

      {/* Modals */}
      {editingQ !== null && (
        <QuestionModal
          q={editingQ === "new" ? null : editingQ}
          onSave={saveQuestion}
          onClose={() => setEditingQ(null)}
        />
      )}
      {editingPart && (
        <PartModal part={editingPart} onSave={savePart} onClose={() => setEditingPart(null)} />
      )}
    </div>
  );
}
