import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { BookOpen, User, Mail, School, Hash, ChevronRight, AlertCircle } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { translate } from "@/i18n/index";
import LanguageSwitcher from "@/components/LanguageSwitcher";

export interface StudentInfo {
  fullName: string;
  email: string;
  school: string;
  studentId: string;
}

export const STUDENT_KEY = "cefr_student";

export default function Register() {
  const [, setLocation] = useLocation();
  const { lang } = useLanguage();
  const T = (k: string) => translate(k, lang);

  const [form, setForm] = useState<StudentInfo>({
    fullName: "",
    email: "",
    school: "",
    studentId: "",
  });
  const [errors, setErrors] = useState<Partial<StudentInfo>>({});
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (localStorage.getItem(STUDENT_KEY)) {
      setLocation("/home");
    }
  }, [setLocation]);

  function validate() {
    const e: Partial<StudentInfo> = {};
    if (!form.fullName.trim()) e.fullName = T("errFullName");
    if (!form.email.trim()) {
      e.email = T("errEmail");
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      e.email = T("errEmailInvalid");
    }
    if (!form.school.trim()) e.school = T("errSchool");
    if (!form.studentId.trim()) e.studentId = T("errStudentId");
    return e;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitted(true);
    const errs = validate();
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    localStorage.setItem(STUDENT_KEY, JSON.stringify(form));
    setLocation("/home");
  }

  function handleChange(field: keyof StudentInfo, value: string) {
    setForm((f) => ({ ...f, [field]: value }));
    if (submitted) {
      setErrors((e) => ({ ...e, [field]: undefined }));
    }
  }

  const fields = [
    { key: "fullName" as const, icon: User, label: T("fullName"), placeholder: T("fullNamePlaceholder"), type: "text" },
    { key: "email" as const, icon: Mail, label: T("email"), placeholder: T("emailPlaceholder"), type: "email" },
    { key: "school" as const, icon: School, label: T("school"), placeholder: T("schoolPlaceholder"), type: "text" },
    { key: "studentId" as const, icon: Hash, label: T("studentId"), placeholder: T("studentIdPlaceholder"), type: "text" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 flex items-center justify-center p-4">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-32 -right-32 w-96 h-96 bg-white/5 rounded-full" />
        <div className="absolute -bottom-20 -left-20 w-72 h-72 bg-white/5 rounded-full" />
        <div className="absolute top-1/2 left-1/4 w-48 h-48 bg-white/3 rounded-full" />
      </div>

      {/* Language switcher top right */}
      <div className="absolute top-4 right-4 z-10">
        <LanguageSwitcher />
      </div>

      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white/15 backdrop-blur-sm rounded-2xl mb-4 border border-white/20">
            <BookOpen className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white tracking-tight">{T("appName")}</h1>
          <p className="text-blue-200 mt-1 text-sm">{T("practiceBadge")}</p>
        </div>

        {/* Form card */}
        <div className="bg-white rounded-2xl shadow-2xl shadow-blue-900/30 p-8">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-slate-800">{T("register")}</h2>
            <p className="text-slate-500 text-sm mt-1">{T("registerSubtitle")}</p>
          </div>

          <form onSubmit={handleSubmit} noValidate className="space-y-5">
            {fields.map(({ key, icon: Icon, label, placeholder, type }) => (
              <div key={key}>
                <label className="block text-sm font-medium text-slate-700 mb-1.5" htmlFor={key}>
                  {label} <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    id={key}
                    data-testid={`input-${key}`}
                    type={type}
                    value={form[key]}
                    onChange={(e) => handleChange(key, e.target.value)}
                    placeholder={placeholder}
                    className={`w-full pl-10 pr-4 py-2.5 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all ${
                      errors[key]
                        ? "border-red-300 bg-red-50"
                        : "border-slate-300 bg-white hover:border-slate-400"
                    }`}
                  />
                </div>
                {errors[key] && (
                  <p className="flex items-center gap-1 text-red-500 text-xs mt-1.5">
                    <AlertCircle className="w-3.5 h-3.5" />
                    {errors[key]}
                  </p>
                )}
              </div>
            ))}

            <button
              data-testid="button-register"
              type="submit"
              className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold py-3 rounded-xl transition-colors shadow-lg shadow-blue-600/25 mt-2"
            >
              {T("startExam")}
              <ChevronRight className="w-5 h-5" />
            </button>
          </form>

          <p className="text-center text-slate-400 text-xs mt-5">{T("privacyNote")}</p>
        </div>
      </div>
    </div>
  );
}
