import { useState, useEffect, useCallback, useRef } from "react";
import { useLocation } from "wouter";
import {
  BookOpen, Headphones, PenLine, Clock, StickyNote, X,
  ChevronLeft, ChevronRight, Highlighter, XCircle, Download,
  AlertCircle, CheckCircle2, Home, User,
} from "lucide-react";
import { type Section, type Part, type Question } from "@/data/examData";
import { loadAdminData, adminToExamData } from "@/data/adminExamData";
import { STUDENT_KEY, type StudentInfo } from "@/pages/Register";
import { useLanguage } from "@/contexts/LanguageContext";
import { translate } from "@/i18n/index";
import LanguageSwitcher from "@/components/LanguageSwitcher";

/* ── Helpers ─────────────────────────────────────────────────────────────── */
function countWords(text: string) {
  return text.trim() === "" ? 0 : text.trim().split(/\s+/).length;
}
function formatTime(seconds: number) {
  const m = Math.floor(seconds / 60).toString().padStart(2, "0");
  const s = (seconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

/* ── Markdown-lite ───────────────────────────────────────────────────────── */
function renderText(text: string) {
  return text.split("\n").map((line, i) => {
    line = line.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
    if (line.trim() === "") return <div key={i} className="h-3" />;
    return (
      <p key={i} className="mb-1 leading-relaxed text-slate-700 text-[15px]"
        dangerouslySetInnerHTML={{ __html: line }} />
    );
  });
}

type Answers = Record<string, string>;

/* ── Question components ─────────────────────────────────────────────────── */
function MCQQuestion({ q, value, onChange, T }: { q: Question; value: string; onChange: (v: string) => void; T: (k: string) => string }) {
  return (
    <div className="mb-7">
      <div className="flex items-start gap-3 mb-3">
        <span className="flex-shrink-0 w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">{q.number}</span>
        <p className="text-slate-800 font-medium leading-snug pt-0.5">{q.prompt}</p>
      </div>
      <div className="ml-10 space-y-2">
        {q.options?.map((opt) => {
          const selected = value === opt.label;
          return (
            <label key={opt.label} data-testid={`option-${q.id}-${opt.label}`}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl border cursor-pointer transition-all select-none ${
                selected ? "bg-blue-50 border-blue-300 shadow-sm" : "bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300"
              }`}>
              <span className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 text-xs font-bold transition-colors ${
                selected ? "bg-blue-600 border-blue-600 text-white" : "border-slate-300 text-slate-400"
              }`}>{opt.label}</span>
              <span className="text-slate-700 text-sm">{opt.text}</span>
              <input type="radio" className="hidden" checked={selected} onChange={() => onChange(opt.label)} />
            </label>
          );
        })}
      </div>
    </div>
  );
}

function GapFillQuestion({ q, value, onChange }: { q: Question; value: string; onChange: (v: string) => void }) {
  return (
    <div className="mb-6 flex items-start gap-3">
      <span className="flex-shrink-0 w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold mt-1">{q.number}</span>
      <div className="flex-1">
        <p className="text-slate-700 text-sm mb-2 leading-relaxed">{q.prompt}</p>
        <input data-testid={`input-${q.id}`} type="text" value={value}
          onChange={(e) => onChange(e.target.value)} placeholder={q.placeholder}
          className="w-full max-w-xs px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white placeholder-slate-400" />
      </div>
    </div>
  );
}

function MatchingQuestion({ q, value, onChange, options, T }: { q: Question; value: string; onChange: (v: string) => void; options: string[]; T: (k: string) => string }) {
  return (
    <div className="mb-5 flex items-center gap-3">
      <span className="flex-shrink-0 w-7 h-7 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">{q.number}</span>
      <span className="text-slate-800 font-medium text-sm flex-1">{q.prompt}</span>
      <select data-testid={`select-${q.id}`} value={value} onChange={(e) => onChange(e.target.value)}
        className="px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-slate-700 min-w-[90px] cursor-pointer">
        <option value="">{T("select")}</option>
        {options.map((opt) => {
          const letter = opt.split(" – ")[0].split(" ")[0];
          return <option key={opt} value={letter}>{letter}</option>;
        })}
      </select>
    </div>
  );
}

function TextareaQuestion({ q, value, onChange, T }: { q: Question; value: string; onChange: (v: string) => void; T: (k: string) => string }) {
  const words = countWords(value);
  const [min, max] = q.wordLimit ? q.wordLimit.replace(/\s/g, "").split("–").map(Number) : [0, Infinity];
  const tooFew = words < min;
  const tooMany = max !== Infinity && words > max;
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <span className="text-slate-600 text-sm font-medium">{T("yourResponse")}</span>
        <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${
          tooMany ? "bg-red-50 text-red-600 border border-red-200"
            : tooFew ? "bg-amber-50 text-amber-600 border border-amber-200"
            : "bg-emerald-50 text-emerald-600 border border-emerald-200"
        }`}>{words} {T("words")}</span>
      </div>
      <textarea data-testid={`textarea-${q.id}`} value={value} onChange={(e) => onChange(e.target.value)}
        placeholder={q.placeholder} rows={10}
        className="w-full px-4 py-3 border border-slate-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white placeholder-slate-400 resize-none leading-relaxed" />
      {q.wordLimit && <p className="text-slate-400 text-xs mt-1.5">{T("wordsTarget")} {q.wordLimit} {T("words")}</p>}
    </div>
  );
}

/* ── Part content ────────────────────────────────────────────────────────── */
function PartContent({ part, answers, setAnswer, highlightMode, T }: {
  part: Part; answers: Answers; setAnswer: (id: string, val: string) => void;
  highlightMode: boolean; T: (k: string) => string;
}) {
  const handleMouseUp = useCallback(() => {
    if (!highlightMode) return;
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed) return;
    try {
      const range = selection.getRangeAt(0);
      const span = document.createElement("mark");
      span.className = "bg-yellow-200 rounded";
      range.surroundContents(span);
      selection.removeAllRanges();
    } catch {}
  }, [highlightMode]);

  const clearHighlights = useCallback(() => {
    document.querySelectorAll("mark.bg-yellow-200").forEach((el) => {
      const parent = el.parentNode;
      if (parent) { while (el.firstChild) parent.insertBefore(el.firstChild, el); parent.removeChild(el); }
    });
  }, []);

  const opts = part.matchOptions ?? [];

  return (
    <div>
      <div className="bg-blue-50 border border-blue-100 rounded-xl px-5 py-4 mb-6">
        <p className="text-slate-700 text-sm leading-relaxed">{part.instructions}</p>
      </div>
      {part.context && (
        <div className="mb-4">
          <p className="text-slate-500 text-xs font-semibold uppercase tracking-widest mb-2">{T("context")}</p>
          <div className="prose prose-sm max-w-none">{renderText(part.context)}</div>
        </div>
      )}
      {part.text && (
        <div className={`bg-slate-50 border border-slate-200 rounded-xl p-5 mb-6 ${highlightMode ? "cursor-text select-text" : "select-none"}`}
          onMouseUp={handleMouseUp}>
          {highlightMode && (
            <div className="flex items-center justify-between mb-3 pb-3 border-b border-slate-200">
              <span className="text-xs text-amber-600 font-medium flex items-center gap-1.5">
                <Highlighter className="w-3.5 h-3.5" /> {T("highlightMode")}
              </span>
              <button onClick={clearHighlights} className="text-xs text-slate-500 hover:text-red-500 transition-colors flex items-center gap-1">
                <XCircle className="w-3.5 h-3.5" /> {T("clearAll")}
              </button>
            </div>
          )}
          <div className="prose prose-sm max-w-none">{renderText(part.text)}</div>
        </div>
      )}
      {part.imageUrl && <div className="mb-6"><img src={part.imageUrl} alt="Exam map" className="rounded-xl border border-slate-200 max-w-full" /></div>}
      {opts.length > 0 && (
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 mb-6">
          <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mb-2">{T("options")}</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1">
            {opts.map((opt) => <span key={opt} className="text-sm text-slate-600">{opt}</span>)}
          </div>
        </div>
      )}
      <div className="mt-2">
        {part.questions.map((q) => {
          const val = answers[q.id] ?? "";
          if (q.type === "mcq") return <MCQQuestion key={q.id} q={q} value={val} onChange={(v) => setAnswer(q.id, v)} T={T} />;
          if (q.type === "gap-fill" || q.type === "one-word-fill") return <GapFillQuestion key={q.id} q={q} value={val} onChange={(v) => setAnswer(q.id, v)} />;
          if (q.type === "matching-dropdown") return <MatchingQuestion key={q.id} q={q} value={val} onChange={(v) => setAnswer(q.id, v)} options={opts} T={T} />;
          if (q.type === "textarea") return <TextareaQuestion key={q.id} q={q} value={val} onChange={(v) => setAnswer(q.id, v)} T={T} />;
          return null;
        })}
      </div>
    </div>
  );
}

/* ── Main Exam ───────────────────────────────────────────────────────────── */
export default function Exam() {
  const [, setLocation] = useLocation();
  const { lang } = useLanguage();
  const T = (k: string) => translate(k, lang);

  // Load exam data from admin storage (multilingual)
  const [examSections, setExamSections] = useState<Section[]>(() => {
    const adminData = loadAdminData();
    return adminToExamData(adminData, lang);
  });

  // Refresh when language changes
  useEffect(() => {
    const adminData = loadAdminData();
    setExamSections(adminToExamData(adminData, lang));
  }, [lang]);

  const [activeSectionIdx, setActiveSectionIdx] = useState(0);
  const [activePartIdx, setActivePartIdx] = useState(0);
  const [answers, setAnswers] = useState<Answers>({});
  const [notesOpen, setNotesOpen] = useState(false);
  const [notes, setNotes] = useState("");
  const [highlightMode, setHighlightMode] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(examSections[0]?.duration * 60 ?? 2700);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const section: Section = examSections[activeSectionIdx];
  const part: Part = section?.parts[activePartIdx];

  const student: StudentInfo | null = (() => {
    try { return JSON.parse(localStorage.getItem(STUDENT_KEY) ?? "null"); } catch { return null; }
  })();

  useEffect(() => {
    if (section) setTimeLeft(section.duration * 60);
  }, [activeSectionIdx]);

  useEffect(() => {
    if (submitted) return;
    timerRef.current = setInterval(() => {
      setTimeLeft((t) => { if (t <= 1) { clearInterval(timerRef.current!); return 0; } return t - 1; });
    }, 1000);
    return () => clearInterval(timerRef.current!);
  }, [activeSectionIdx, submitted]);

  const setAnswer = useCallback((id: string, val: string) => {
    setAnswers((prev) => ({ ...prev, [id]: val }));
  }, []);

  function switchSection(idx: number) {
    setActiveSectionIdx(idx);
    setActivePartIdx(0);
    setHighlightMode(false);
  }

  function answered(q: Question) { return !!(answers[q.id] && answers[q.id].trim() !== ""); }
  function partAnswered(p: Part) { return p.questions.filter(answered).length; }
  function totalAnswered() { return examSections.flatMap(s => s.parts.flatMap(p => p.questions)).filter(answered).length; }
  function totalQuestions() { return examSections.flatMap(s => s.parts.flatMap(p => p.questions)).length; }

  function downloadWriting() {
    const lines = ["WRITING RESPONSES\n==================\n"];
    examSections.find(s => s.id === "writing")?.parts.forEach(p => {
      lines.push(`\n${p.title} — ${p.range}`);
      lines.push("-".repeat(40));
      p.questions.forEach(q => { lines.push(answers[q.id] ?? "(no response)"); });
    });
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "writing_responses.txt"; a.click();
    URL.revokeObjectURL(url);
  }

  function downloadResults() {
    const lines = ["EXAM RESULTS\n============\n"];
    examSections.forEach(sec => {
      lines.push(`\n== ${sec.title.toUpperCase()} ==`);
      sec.parts.forEach(p => {
        lines.push(`\n${p.title} (${p.range})`);
        p.questions.forEach(q => { lines.push(`  Q${q.number}: ${answers[q.id] ?? "(blank)"}`); });
      });
    });
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "exam_results.txt"; a.click();
    URL.revokeObjectURL(url);
  }

  const timerWarning = timeLeft < 300;

  function SectionIcon({ id }: { id: string }) {
    if (id === "listening") return <Headphones className="w-4 h-4" />;
    if (id === "reading") return <BookOpen className="w-4 h-4" />;
    return <PenLine className="w-4 h-4" />;
  }

  /* ── Submitted screen ── */
  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50/30 flex items-center justify-center p-6">
        <div className="bg-white rounded-2xl shadow-xl p-10 max-w-md w-full text-center border border-slate-200">
          <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-5">
            <CheckCircle2 className="w-8 h-8 text-emerald-500" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">{T("examSubmitted")}</h2>
          <p className="text-slate-500 mb-1">
            {T("answeredOf")} <span className="font-semibold text-slate-700">{totalAnswered()}</span>{" "}
            {T("outOf")} <span className="font-semibold text-slate-700">{totalQuestions()}</span>{" "}
            {T("questions2")}
          </p>
          <p className="text-slate-400 text-sm mb-8">{T("downloadNote")}</p>
          <div className="flex flex-col gap-3">
            <button data-testid="button-download-results" onClick={downloadResults}
              className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-xl transition-colors">
              <Download className="w-4 h-4" /> {T("downloadResults")}
            </button>
            <button data-testid="button-download-writing" onClick={downloadWriting}
              className="flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-6 py-3 rounded-xl transition-colors">
              <Download className="w-4 h-4" /> {T("downloadWriting")}
            </button>
            <button data-testid="button-go-home" onClick={() => setLocation("/home")}
              className="flex items-center justify-center gap-2 text-slate-500 hover:text-slate-700 font-medium px-6 py-3 rounded-xl transition-colors hover:bg-slate-50">
              <Home className="w-4 h-4" /> {T("backToHome")}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2 mr-2">
            <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center">
              <BookOpen className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-slate-800 text-sm hidden sm:block">{T("appName")}</span>
          </div>

          {/* Section tabs */}
          <div className="flex items-center gap-1 flex-1">
            {examSections.map((sec, i) => (
              <button key={sec.id} data-testid={`tab-section-${sec.id}`} onClick={() => switchSection(i)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeSectionIdx === i ? "bg-blue-600 text-white shadow-sm" : "text-slate-600 hover:bg-slate-100"
                }`}>
                <SectionIcon id={sec.id} />
                <span className="hidden sm:inline">{T(sec.id)}</span>
                <span className="text-xs opacity-70 hidden md:inline">{sec.duration} {T("minutes")}</span>
              </button>
            ))}
          </div>

          {/* Student */}
          {student && (
            <div className="hidden md:flex items-center gap-1.5 text-xs text-slate-500 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-full">
              <User className="w-3.5 h-3.5 text-slate-400" />
              <span className="font-medium max-w-[120px] truncate">{student.fullName}</span>
            </div>
          )}

          {/* Right controls */}
          <div className="flex items-center gap-2">
            <LanguageSwitcher />

            <button data-testid="button-highlight" onClick={() => setHighlightMode((h) => !h)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                highlightMode ? "bg-amber-50 border-amber-300 text-amber-700" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
              }`}>
              <Highlighter className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{highlightMode ? T("clear") : T("highlight")}</span>
            </button>

            <button data-testid="button-notes" onClick={() => setNotesOpen((o) => !o)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border bg-white border-slate-200 text-slate-600 hover:bg-slate-50 transition-all">
              <StickyNote className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{T("notes")}</span>
            </button>

            <div data-testid="timer-display"
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-mono font-bold border transition-all ${
                timerWarning ? "bg-red-50 border-red-200 text-red-600 animate-pulse" : "bg-slate-50 border-slate-200 text-slate-700"
              }`}>
              <Clock className="w-3.5 h-3.5" />
              {formatTime(timeLeft)}
            </div>

            <button data-testid="button-submit" onClick={() => setSubmitted(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-1.5 rounded-lg text-sm transition-colors hidden sm:block">
              {T("submit")}
            </button>
          </div>
        </div>

        {/* Part nav sub-bar */}
        <div className="border-t border-slate-100 bg-white">
          <div className="max-w-7xl mx-auto px-4 flex items-center gap-1 py-2 overflow-x-auto">
            <span className="text-xs text-slate-400 font-medium mr-1 flex-shrink-0">{T("parts")}</span>
            {section?.parts.map((p, i) => {
              const ans = partAnswered(p);
              const total = p.questions.length;
              const active = activePartIdx === i;
              return (
                <button key={p.id} data-testid={`tab-part-${p.id}`} onClick={() => setActivePartIdx(i)}
                  className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-medium transition-all ${
                    active ? "bg-blue-100 text-blue-700 border border-blue-200" : "text-slate-600 hover:bg-slate-100 border border-transparent"
                  }`}>
                  {p.title}
                  <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full ${
                    ans === total ? "bg-emerald-100 text-emerald-600" : ans > 0 ? "bg-amber-100 text-amber-600" : "bg-slate-100 text-slate-400"
                  }`}>{ans}/{total}</span>
                </button>
              );
            })}
            <div className="flex-1" />
            <span className="text-xs text-slate-400 flex-shrink-0">
              {T("total")} {totalAnswered()}/{totalQuestions()}
            </span>
          </div>
        </div>
      </header>

      {/* Main */}
      <div className="flex-1 max-w-4xl mx-auto w-full px-4 py-8">
        {part && (
          <>
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest">{T(section.id)}</span>
                <span className="text-slate-300">›</span>
                <span className="text-xs font-semibold text-blue-600">{part.title}</span>
                {part.range && <span className="text-xs text-slate-400">({part.range})</span>}
              </div>
              <h2 className="text-xl font-bold text-slate-800">
                {part.title}
                {part.range && <span className="text-slate-400 font-normal text-base ml-2">Questions {part.range}</span>}
              </h2>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 md:p-8">
              <PartContent part={part} answers={answers} setAnswer={setAnswer} highlightMode={highlightMode} T={T} />
            </div>

            {/* Prev / Next */}
            <div className="flex items-center justify-between mt-6">
              <button data-testid="button-prev-part"
                onClick={() => {
                  if (activePartIdx > 0) setActivePartIdx(i => i - 1);
                  else if (activeSectionIdx > 0) {
                    const prev = examSections[activeSectionIdx - 1];
                    setActiveSectionIdx(i => i - 1);
                    setActivePartIdx(prev.parts.length - 1);
                  }
                }}
                disabled={activeSectionIdx === 0 && activePartIdx === 0}
                className="flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-all">
                <ChevronLeft className="w-4 h-4" /> {T("previous")}
              </button>

              <button onClick={() => setSubmitted(true)}
                className="sm:hidden bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-2 rounded-xl text-sm transition-colors">
                {T("submit")}
              </button>

              <button data-testid="button-next-part"
                onClick={() => {
                  if (activePartIdx < section.parts.length - 1) setActivePartIdx(i => i + 1);
                  else if (activeSectionIdx < examSections.length - 1) {
                    setActiveSectionIdx(i => i + 1);
                    setActivePartIdx(0);
                  }
                }}
                disabled={activeSectionIdx === examSections.length - 1 && activePartIdx === section.parts.length - 1}
                className="flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed transition-all">
                {T("next")} <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </>
        )}
      </div>

      {/* Notes panel */}
      {notesOpen && (
        <div className="fixed bottom-0 right-0 w-full sm:w-96 h-72 bg-white border border-slate-200 rounded-tl-2xl shadow-2xl z-40 flex flex-col">
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <StickyNote className="w-4 h-4 text-amber-500" />
              <span className="font-semibold text-slate-700 text-sm">{T("notes")}</span>
            </div>
            <button data-testid="button-close-notes" onClick={() => setNotesOpen(false)}
              className="text-slate-400 hover:text-slate-600 transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>
          <textarea data-testid="textarea-notes" value={notes} onChange={(e) => setNotes(e.target.value)}
            placeholder={T("writeNotes")}
            className="flex-1 px-4 py-3 text-sm text-slate-700 resize-none focus:outline-none placeholder-slate-300" />
        </div>
      )}

      {/* Timer warning */}
      {timerWarning && timeLeft > 0 && (
        <div className="fixed top-16 left-0 right-0 z-20 flex justify-center pointer-events-none">
          <div className="flex items-center gap-2 bg-red-600 text-white px-5 py-2 rounded-b-xl shadow-lg text-sm font-medium animate-bounce">
            <AlertCircle className="w-4 h-4" /> {T("timerWarning")}
          </div>
        </div>
      )}
    </div>
  );
}
