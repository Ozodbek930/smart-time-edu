import { useLocation } from "wouter";
import { BookOpen, Headphones, PenLine, Clock, ChevronRight, CheckCircle, LogOut, User, Settings } from "lucide-react";
import { STUDENT_KEY, type StudentInfo } from "@/pages/Register";
import { useLanguage } from "@/contexts/LanguageContext";
import { translate } from "@/i18n/index";
import LanguageSwitcher from "@/components/LanguageSwitcher";

export default function Home() {
  const [, setLocation] = useLocation();
  const { lang } = useLanguage();
  const T = (k: string) => translate(k, lang);

  const student: StudentInfo | null = (() => {
    try { return JSON.parse(localStorage.getItem(STUDENT_KEY) ?? "null"); } catch { return null; }
  })();

  function logout() {
    localStorage.removeItem(STUDENT_KEY);
    setLocation("/");
  }

  const instrList = (Array.isArray(translate("instructions", lang))
    ? translate("instructions", lang)
    : (translate("instructions", lang) as unknown as string[])
  ) as unknown as string[];

  const instrArray: string[] = Array.isArray(instrList) ? instrList : [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-indigo-50/40">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-blue-600 rounded-lg flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <div>
              <span className="font-semibold text-slate-800 text-lg tracking-tight">{T("appName")}</span>
              <span className="text-xs text-slate-400 ml-2 font-medium">{T("appSubtitle")}</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="bg-blue-50 text-blue-700 font-semibold px-3 py-1 rounded-full text-xs border border-blue-100">{T("levelBadge")}</span>
            <LanguageSwitcher />
            {student && (
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-full px-3 py-1.5">
                  <div className="w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="w-3 h-3 text-white" />
                  </div>
                  <span className="text-slate-700 text-xs font-medium max-w-[140px] truncate">{student.fullName}</span>
                </div>
                <button
                  data-testid="button-logout"
                  onClick={logout}
                  title={T("logout")}
                  className="text-slate-400 hover:text-red-500 transition-colors p-1.5 rounded-lg hover:bg-red-50"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="max-w-6xl mx-auto px-6 py-16">
        {/* Student card */}
        {student && (
          <div className="bg-white border border-slate-200 rounded-2xl px-6 py-4 mb-10 flex items-center gap-4 shadow-sm">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
              <span className="text-white font-bold text-sm">
                {student.fullName.trim().charAt(0).toUpperCase()}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-slate-800 truncate">{student.fullName}</p>
              <p className="text-slate-400 text-xs">{student.school} · {student.studentId} · {student.email}</p>
            </div>
            <button
              onClick={() => setLocation("/admin")}
              title="Admin Panel"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-50 hover:text-slate-700 text-xs font-medium transition-colors"
            >
              <Settings className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Admin</span>
            </button>
          </div>
        )}

        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 bg-blue-50 border border-blue-100 text-blue-700 px-4 py-1.5 rounded-full text-sm font-medium mb-6">
            <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
            {T("practiceBadge")}
          </div>
          <h1 className="text-5xl font-bold text-slate-900 mb-4 tracking-tight leading-tight">
            {T("heroTitle1")}<br />
            <span className="text-blue-600">{T("heroTitle2")}</span>
          </h1>
          <p className="text-xl text-slate-500 max-w-2xl mx-auto leading-relaxed">
            {T("heroDesc")}
          </p>
        </div>

        {/* Sections */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {[
            { icon: Headphones, color: "indigo", title: "listening", desc: "listeningDesc" },
            { icon: BookOpen, color: "emerald", title: "reading", desc: "readingDesc" },
            { icon: PenLine, color: "amber", title: "writing", desc: "writingDesc" },
          ].map(({ icon: Icon, color, title, desc }) => (
            <div key={title} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
              <div className={`w-12 h-12 bg-${color}-50 rounded-xl flex items-center justify-center mb-4`}>
                <Icon className={`w-6 h-6 text-${color}-600`} />
              </div>
              <h3 className="font-semibold text-slate-800 text-lg mb-2">{T(title)}</h3>
              <p className="text-slate-500 text-sm mb-4 leading-relaxed">{T(desc)}</p>
              <div className="flex items-center gap-2 text-slate-400 text-sm">
                <Clock className="w-4 h-4" />
                <span>{title === "listening" ? 45 : 60} {T("minutes")}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Instructions */}
        <div className="bg-white rounded-2xl p-8 border border-slate-200 shadow-sm mb-10">
          <h2 className="font-semibold text-slate-800 text-lg mb-5">{T("beforeYouBegin")}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {instrArray.map((item: string, i: number) => (
              <div key={i} className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
                <span className="text-slate-600 text-sm leading-relaxed">{item}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Start */}
        <div className="text-center">
          <button
            data-testid="button-start-exam"
            onClick={() => setLocation("/exam")}
            className="inline-flex items-center gap-3 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold px-10 py-4 rounded-xl text-lg transition-colors shadow-lg shadow-blue-600/25 hover:shadow-blue-600/40"
          >
            {T("startMockExam")}
            <ChevronRight className="w-5 h-5" />
          </button>
          <p className="text-slate-400 text-sm mt-4">{T("examDuration")}</p>
        </div>
      </main>
    </div>
  );
}
