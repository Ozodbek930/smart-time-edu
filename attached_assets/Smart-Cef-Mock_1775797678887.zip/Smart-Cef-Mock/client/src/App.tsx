import { Switch, Route, useLocation } from "wouter";
import { useEffect } from "react";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { LanguageProvider } from "@/contexts/LanguageContext";
import NotFound from "@/pages/not-found";
import Register, { STUDENT_KEY } from "@/pages/Register";
import Home from "@/pages/Home";
import Exam from "@/pages/Exam";
import Admin from "@/pages/Admin";

function GuardedRoute({ component: Component }: { component: React.ComponentType }) {
  const [, setLocation] = useLocation();
  useEffect(() => {
    if (!localStorage.getItem(STUDENT_KEY)) {
      setLocation("/");
    }
  }, [setLocation]);
  if (!localStorage.getItem(STUDENT_KEY)) return null;
  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Register} />
      <Route path="/home">
        {() => <GuardedRoute component={Home} />}
      </Route>
      <Route path="/exam">
        {() => <GuardedRoute component={Exam} />}
      </Route>
      <Route path="/admin" component={Admin} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
