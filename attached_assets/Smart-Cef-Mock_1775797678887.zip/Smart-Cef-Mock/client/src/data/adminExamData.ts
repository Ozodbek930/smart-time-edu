import { examData, type Section, type Part, type Question, type MCQOption, type QuestionType } from "./examData";

export const ADMIN_DATA_KEY = "cefr_admin_data";
export const ADMIN_AUTH_KEY = "cefr_admin_auth";
export const ADMIN_PASSWORD = "admin123";

export type MultiLang = { en: string; ru: string; uz: string };

export interface AdminOption {
  label: string;
  text: MultiLang;
}

export interface AdminQuestion {
  id: string;
  number: number;
  type: QuestionType;
  prompt: MultiLang;
  options?: AdminOption[];
  placeholder?: MultiLang;
  wordLimit?: string;
}

export interface AdminPart {
  id: string;
  title: string;
  range: string;
  instructions: MultiLang;
  context?: MultiLang;
  text?: MultiLang;
  imageUrl?: string;
  matchOptions?: string[];
  questions: AdminQuestion[];
}

export interface AdminSection {
  id: string;
  title: string;
  duration: number;
  parts: AdminPart[];
}

export type AdminData = AdminSection[];

/* Convert default examData to AdminData (English only) */
export function buildDefaultAdminData(): AdminData {
  return examData.map((section): AdminSection => ({
    id: section.id,
    title: section.title,
    duration: section.duration,
    parts: section.parts.map((part): AdminPart => ({
      id: part.id,
      title: part.title,
      range: part.range,
      instructions: { en: part.instructions, ru: "", uz: "" },
      context: part.context ? { en: part.context, ru: "", uz: "" } : undefined,
      text: part.text ? { en: part.text, ru: "", uz: "" } : undefined,
      imageUrl: part.imageUrl,
      matchOptions: part.matchOptions,
      questions: part.questions.map((q): AdminQuestion => ({
        id: q.id,
        number: q.number,
        type: q.type,
        prompt: { en: q.prompt ?? "", ru: "", uz: "" },
        options: q.options?.map((opt): AdminOption => ({
          label: opt.label,
          text: { en: opt.text, ru: "", uz: "" },
        })),
        placeholder: q.placeholder ? { en: q.placeholder, ru: "", uz: "" } : undefined,
        wordLimit: q.wordLimit,
      })),
    })),
  }));
}

export function loadAdminData(): AdminData {
  try {
    const raw = localStorage.getItem(ADMIN_DATA_KEY);
    if (raw) return JSON.parse(raw) as AdminData;
  } catch {}
  return buildDefaultAdminData();
}

export function saveAdminData(data: AdminData) {
  localStorage.setItem(ADMIN_DATA_KEY, JSON.stringify(data));
}

export function resetAdminData() {
  localStorage.removeItem(ADMIN_DATA_KEY);
}

/* Convert AdminData back to the Section[] format for the Exam page */
import { type Lang } from "@/i18n/index";

function ml(v: MultiLang | undefined, lang: Lang): string {
  if (!v) return "";
  return (v[lang] && v[lang].trim()) ? v[lang] : v.en;
}

export function adminToExamData(data: AdminData, lang: Lang): Section[] {
  return data.map((sec): Section => ({
    id: sec.id,
    title: sec.title,
    duration: sec.duration,
    parts: sec.parts.map((part): Part => ({
      id: part.id,
      title: part.title,
      range: part.range,
      instructions: ml(part.instructions, lang),
      context: part.context ? ml(part.context, lang) : undefined,
      text: part.text ? ml(part.text, lang) : undefined,
      imageUrl: part.imageUrl,
      matchOptions: part.matchOptions,
      questions: part.questions.map((q): Question => ({
        id: q.id,
        number: q.number,
        type: q.type,
        prompt: ml(q.prompt, lang),
        options: q.options?.map((opt): MCQOption => ({
          label: opt.label,
          text: ml(opt.text, lang),
        })),
        placeholder: q.placeholder ? ml(q.placeholder, lang) : undefined,
        wordLimit: q.wordLimit,
      })),
    })),
  }));
}

export function generateId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}
