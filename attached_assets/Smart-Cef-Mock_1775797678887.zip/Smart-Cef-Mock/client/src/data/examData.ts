export type QuestionType =
  | "mcq"
  | "gap-fill"
  | "matching-dropdown"
  | "one-word-fill"
  | "textarea";

export interface MCQOption {
  label: string;
  text: string;
}

export interface Question {
  id: string;
  number: number;
  type: QuestionType;
  prompt?: string;
  options?: MCQOption[];
  matchOptions?: string[];
  placeholder?: string;
  wordLimit?: string;
}

export interface Part {
  id: string;
  title: string;
  range: string;
  instructions: string;
  context?: string;
  text?: string;
  imageUrl?: string;
  questions: Question[];
  matchOptions?: string[];
}

export interface Section {
  id: string;
  title: string;
  duration: number;
  parts: Part[];
}

export const examData: Section[] = [
  {
    id: "listening",
    title: "Listening",
    duration: 45,
    parts: [
      {
        id: "listening-1",
        title: "Part 1",
        range: "1–8",
        instructions:
          "You will hear some sentences. You will hear each sentence twice. Choose the correct reply to each sentence (A, B, or C). Mark your answers on the answer sheet.",
        questions: [
          {
            id: "l1q1",
            number: 1,
            type: "mcq",
            prompt: "Choose the correct reply.",
            options: [
              { label: "A", text: "What a pity!" },
              { label: "B", text: "Yes, of course." },
              { label: "C", text: "No, thanks." },
            ],
          },
          {
            id: "l1q2",
            number: 2,
            type: "mcq",
            prompt: "Choose the correct reply.",
            options: [
              { label: "A", text: "This car's mine." },
              { label: "B", text: "He can't drive." },
              { label: "C", text: "I'm so sorry." },
            ],
          },
          {
            id: "l1q3",
            number: 3,
            type: "mcq",
            prompt: "Choose the correct reply.",
            options: [
              { label: "A", text: "That's right" },
              { label: "B", text: "They aren't." },
              { label: "C", text: "I'm not there" },
            ],
          },
          {
            id: "l1q4",
            number: 4,
            type: "mcq",
            prompt: "Choose the correct reply.",
            options: [
              { label: "A", text: "She likes chocolate" },
              { label: "B", text: "He's a kind boy." },
              { label: "C", text: "He's quite tall." },
            ],
          },
          {
            id: "l1q5",
            number: 5,
            type: "mcq",
            prompt: "Choose the correct reply.",
            options: [
              { label: "A", text: "See you later." },
              { label: "B", text: "Good idea." },
              { label: "C", text: "Please come in" },
            ],
          },
          {
            id: "l1q6",
            number: 6,
            type: "mcq",
            prompt: "Choose the correct reply.",
            options: [
              { label: "A", text: "He speaks French" },
              { label: "B", text: "I'm sorry, he's out" },
              { label: "C", text: "Talk you later." },
            ],
          },
          {
            id: "l1q7",
            number: 7,
            type: "mcq",
            prompt: "Choose the correct reply.",
            options: [
              { label: "A", text: "Thanks a lot." },
              { label: "B", text: "Please don't." },
              { label: "C", text: "Here you are" },
            ],
          },
          {
            id: "l1q8",
            number: 8,
            type: "mcq",
            prompt: "Choose the correct reply.",
            options: [
              { label: "A", text: "Sorry, no way." },
              { label: "B", text: "Sorry, no idea." },
              { label: "C", text: "Sorry, no time" },
            ],
          },
        ],
      },
      {
        id: "listening-2",
        title: "Part 2",
        range: "9–14",
        instructions:
          "For each question, write the correct answer in the gap. Write one or two words, a number, a date, or a time. You will hear a teacher giving some information to students about a special destination for their school trip.",
        context: "Amazing Holidays",
        questions: [
          {
            id: "l2q9",
            number: 9,
            type: "gap-fill",
            prompt:
              "Benefits of The Great Wall of China tour: not overcrowded; excellent",
            placeholder: "answer...",
          },
          {
            id: "l2q10",
            number: 10,
            type: "gap-fill",
            prompt: "Mount Everest: last trip is on",
            placeholder: "date...",
          },
          {
            id: "l2q11",
            number: 11,
            type: "gap-fill",
            prompt: "Cookery holidays: China or Vietnam tour: go to ___ for shopping",
            placeholder: "place...",
          },
          {
            id: "l2q12",
            number: 12,
            type: "gap-fill",
            prompt: "Panda Rescue Centre: class on making panda",
            placeholder: "answer...",
          },
          {
            id: "l2q13",
            number: 13,
            type: "gap-fill",
            prompt: "Mexico Food Adventure: visit the",
            placeholder: "answer...",
          },
          {
            id: "l2q14",
            number: 14,
            type: "gap-fill",
            prompt: "For more information: ___ holiday.com",
            placeholder: "answer...",
          },
        ],
      },
      {
        id: "listening-3",
        title: "Part 3",
        range: "15–19",
        instructions:
          "You will hear five different people talking about visits they have made to a hospital. For questions 15–19, choose from the list A–H the reasons why each attended the hospital on the occasion described. Use the letters only once. There are three extra letters which you do not need to use.",
        matchOptions: [
          "A – to accompany a relative",
          "B – to visit a sick friend",
          "C – to have a test done",
          "D – to collect a prescription",
          "E – to attend a clinic",
          "F – to have an operation",
          "G – to see a specialist",
          "H – to deal with an emergency",
        ],
        questions: [
          {
            id: "l3q15",
            number: 15,
            type: "matching-dropdown",
            prompt: "Speaker 1",
          },
          {
            id: "l3q16",
            number: 16,
            type: "matching-dropdown",
            prompt: "Speaker 2",
          },
          {
            id: "l3q17",
            number: 17,
            type: "matching-dropdown",
            prompt: "Speaker 3",
          },
          {
            id: "l3q18",
            number: 18,
            type: "matching-dropdown",
            prompt: "Speaker 4",
          },
          {
            id: "l3q19",
            number: 19,
            type: "matching-dropdown",
            prompt: "Speaker 5",
          },
        ],
      },
      {
        id: "listening-4",
        title: "Part 4",
        range: "20–24",
        instructions:
          "Write the correct letter, A–H, next to Questions 20–24.",
        context: "Branley Castle",
        imageUrl: "https://smartcefrmock.netlify.app/assets/branley_castle_map.png",
        matchOptions: ["A", "B", "C", "D", "E", "F", "G", "H"],
        questions: [
          {
            id: "l4q20",
            number: 20,
            type: "matching-dropdown",
            prompt: "Starting point for walking the walls",
          },
          {
            id: "l4q21",
            number: 21,
            type: "matching-dropdown",
            prompt: "Bow and arrow display",
          },
          {
            id: "l4q22",
            number: 22,
            type: "matching-dropdown",
            prompt: "Hunting birds display",
          },
          {
            id: "l4q23",
            number: 23,
            type: "matching-dropdown",
            prompt: "Traditional dancing",
          },
          {
            id: "l4q24",
            number: 24,
            type: "matching-dropdown",
            prompt: "Shop",
          },
        ],
      },
      {
        id: "listening-5",
        title: "Part 5",
        range: "25–30",
        instructions:
          "Extract One / Two / Three. For each question, choose the correct answer (A, B, or C).",
        questions: [
          {
            id: "l5q25",
            number: 25,
            type: "mcq",
            prompt: "Extract One: The man thinks the essential component of a holiday is",
            options: [
              { label: "A", text: "physical activity." },
              { label: "B", text: "the opportunity to travel." },
              { label: "C", text: "mental stimulation." },
            ],
          },
          {
            id: "l5q26",
            number: 26,
            type: "mcq",
            prompt:
              "He feels that one benefit of doing archaeology on holiday is that it",
            options: [
              { label: "A", text: "provides him with the excitement of discovery." },
              { label: "B", text: "adds to the sum of his knowledge." },
              { label: "C", text: "helps him to be more tolerant." },
            ],
          },
          {
            id: "l5q27",
            number: 27,
            type: "mcq",
            prompt: "Extract Two: They agree that being late",
            options: [
              { label: "A", text: "is a growing trend." },
              { label: "B", text: "is a difficult habit to break." },
              { label: "C", text: "can be amusing when it affects others." },
            ],
          },
          {
            id: "l5q28",
            number: 28,
            type: "mcq",
            prompt: "In the woman's opinion, people who fail to arrive on time",
            options: [
              {
                label: "A",
                text: "are often completely unaware of the problems they cause.",
              },
              { label: "B", text: "generally have a relaxed attitude to life." },
              { label: "C", text: "are putting their career prospects at risk." },
            ],
          },
          {
            id: "l5q29",
            number: 29,
            type: "mcq",
            prompt: "Extract Three: The woman thinks the novelist manages to",
            options: [
              { label: "A", text: "create a credible background." },
              { label: "B", text: "exploit a strong story line." },
              { label: "C", text: "depict well-drawn characters." },
            ],
          },
          {
            id: "l5q30",
            number: 30,
            type: "mcq",
            prompt: "The friends agree that this historical novel",
            options: [
              { label: "A", text: "gives a successful insight into the past." },
              { label: "B", text: "provides an escape from the present." },
              { label: "C", text: "presents a highly subjective view of events." },
            ],
          },
        ],
      },
      {
        id: "listening-6",
        title: "Part 6",
        range: "31–35",
        instructions:
          "Write ONE WORD ONLY for each answer.",
        context: "Agricultural programme in Mozambique",
        questions: [
          {
            id: "l6q31",
            number: 31,
            type: "one-word-fill",
            prompt:
              "___ was seen as the main priority to ensure the supply of water.",
            placeholder: "one word...",
          },
          {
            id: "l6q32",
            number: 32,
            type: "one-word-fill",
            prompt:
              "Most of the work organised by farmers' associations was done by ___",
            placeholder: "one word...",
          },
          {
            id: "l6q33",
            number: 33,
            type: "one-word-fill",
            prompt: "The programme provided ___ for the fences",
            placeholder: "one word...",
          },
          {
            id: "l6q34",
            number: 34,
            type: "one-word-fill",
            prompt: "The programme provided ___ for suitable crops",
            placeholder: "one word...",
          },
          {
            id: "l6q35",
            number: 35,
            type: "one-word-fill",
            prompt: "The farmers provided ___ for the fences on their land",
            placeholder: "one word...",
          },
        ],
      },
    ],
  },
  {
    id: "reading",
    title: "Reading",
    duration: 60,
    parts: [
      {
        id: "reading-1",
        title: "Part 1",
        range: "1–6",
        instructions:
          "Read the text below and decide which word (A–D) best fits each gap.",
        text: `**Jack Calder** — Violin player Jack Calder plays in the Australian band, Ocean Blue.

Jack Calder started playing the violin when he was ten. "My music teacher played and one day he asked if anyone wanted to learn. Some girls put up their hands and I wished to (1)____. I didn't have a (2)____, but my uncle said I could use his. The lessons were really hard at first, but playing the violin soon became important to me. So I got used to the (3)____."

After leaving school, Jack moved to Melbourne. For a time, he preferred listening to music to playing it. The rock music he listened to sounded very different from violin (4)____, so he bought an electric violin, and started putting the things he liked about rock music into the music he played on his violin. Doing this is not (5)____ anymore.

A year later, Jack met a small group of Melbourne musicians. "We all thought about music in the same way and started Ocean Blue together. A year later, we were (6)____ in lots of concerts, and our music was selling well. But we didn't want this to make us different people. We didn't want to stop being friends."`,
        questions: [
          {
            id: "r1q1",
            number: 1,
            type: "gap-fill",
            prompt: "Gap 1",
            placeholder: "word...",
          },
          {
            id: "r1q2",
            number: 2,
            type: "gap-fill",
            prompt: "Gap 2",
            placeholder: "word...",
          },
          {
            id: "r1q3",
            number: 3,
            type: "gap-fill",
            prompt: "Gap 3",
            placeholder: "word...",
          },
          {
            id: "r1q4",
            number: 4,
            type: "gap-fill",
            prompt: "Gap 4",
            placeholder: "word...",
          },
          {
            id: "r1q5",
            number: 5,
            type: "gap-fill",
            prompt: "Gap 5",
            placeholder: "word...",
          },
          {
            id: "r1q6",
            number: 6,
            type: "gap-fill",
            prompt: "Gap 6",
            placeholder: "word...",
          },
        ],
      },
      {
        id: "reading-2",
        title: "Part 2",
        range: "7–14",
        instructions:
          "The text below has some gaps. For each gap (7–14), choose the sentence (A–J) that best fits. There are two extra sentences you do not need to use.",
        text: `**Bars and Restaurants**

**7. BAR 4U** — You can watch the world go by through the big windows at the front of this busy city cafe. The menu includes fish and seafood, and you can sit there if you like, even if you're only having a glass of fruit juice.

**8. ALL THE RAJ** — This city centre Indian restaurant, taking a comfortable but rather smoky place, offers some traditional vegetarian dishes as well as its well-known chicken and lamb food. Prices are not expensive, and there is a small wine list.

**9. THE HARVEST HOME** — Just out the busy Cheltenham road, in the pretty village of Wibbly, this restaurant with its large car park is popular with passing motorists. The restaurant serves good simple food in a friendly and relaxed atmosphere.

**10. THE OASIS** — Take plenty of money with you if you go to this famous restaurant in the center of the city. The owner changed six months ago, but people say that the new owner, who trained as a chef in Paris, is just as good.

**11. LOCH TEEN** — New in town, located in a basement room, this speciality seafood bar is already quite popular. Because of the limited space, they have to have two timetables – early evening (6.30) and later (8.30) and you might feel it's a bit rushed.

**12. THE TERRACE WINE BAR** — You can sit outside and eat under the stars here, where they serve food from midday till 3 am. The food is simple – crepes, pasta, burger – and good wine sorts, they serve beers from over 50 countries.

**13. DOWN TO EARTH** — This bright, white restaurant (no smoking allowed) is situated next to the central train station. It's vegetables only here with a whole new world of delicious and imaginative dishes.

**14. JOE'S DINER** — Open early and late, this snack-bar is popular with both market workers and city business people. You'll only get quick and simple meals, but they'll be well cooked and quickly served. No alcohol licence.`,
        matchOptions: [
          "A – This place is perfect for people who enjoy drinking wine outside at midnights.",
          "B – Visitors may bring their alcohol or other drinks with themselves.",
          "C – You won't have any problem with parking due its big size.",
          "D – This restaurant is perfect for people who usually suffer from the shortage of time.",
          "E – Guests should follow the schedule offered by the bar due to its limited space but high popularity.",
          "F – You can enjoy the view of city along with eating seafood in this restaurant.",
          "G – This restaurant may not serve clients during weekends.",
          "H – It may cost a lot to have a dinner there because of the city center location.",
          "I – Visitors who want to leave the city by train may choose this place unless they smoke.",
          "J – If you don't eat meat and prefer smoking while sitting, this place is right for you.",
        ],
        questions: [
          {
            id: "r2q7",
            number: 7,
            type: "matching-dropdown",
            prompt: "Text 7 matches statement",
          },
          {
            id: "r2q8",
            number: 8,
            type: "matching-dropdown",
            prompt: "Text 8 matches statement",
          },
          {
            id: "r2q9",
            number: 9,
            type: "matching-dropdown",
            prompt: "Text 9 matches statement",
          },
          {
            id: "r2q10",
            number: 10,
            type: "matching-dropdown",
            prompt: "Text 10 matches statement",
          },
          {
            id: "r2q11",
            number: 11,
            type: "matching-dropdown",
            prompt: "Text 11 matches statement",
          },
          {
            id: "r2q12",
            number: 12,
            type: "matching-dropdown",
            prompt: "Text 12 matches statement",
          },
          {
            id: "r2q13",
            number: 13,
            type: "matching-dropdown",
            prompt: "Text 13 matches statement",
          },
          {
            id: "r2q14",
            number: 14,
            type: "matching-dropdown",
            prompt: "Text 14 matches statement",
          },
        ],
      },
      {
        id: "reading-3",
        title: "Part 3",
        range: "15–20",
        instructions:
          "Read the text below. Match each paragraph (I–VI) to the heading (A–H) that best summarises it. There are two extra headings you do not need to use.",
        text: `**I.** The world's first public passenger railway was built in Great Britain in 1826 and ran between the industrial north-eastern towns of Stockton and Darlington. After 180 years' experience the British say that their trains still don't seem to run efficiently or even safely. On average, about 500 accidents with broken rail tracks happen in the country every year.

**II.** The British government is promising to give £33.5 billion to modernize the railways before 2010. Another £30 billion is to come from the private sector. The main target is to increase safety and speed. For example, new London-to-Scotland high-speed trains significantly reduce journey times and in 2004 a warning system was installed throughout the country.

**III.** Statistics show that only 12% of all journeys made in Britain are by public transport. The remaining 88% are made by car. Every year British people spend about two weeks travelling to and from work including nine days in their own cars. But anyone will say this isn't a quick and easy way to travel. In fact, a journey from London to Manchester frequently takes seven hours. A cyclist could get there quicker.

**IV.** Every year there are about half a million traffic jams in Britain. That is nearly 10,000 a week. There are hundreds of big traffic jams every day. According to the forecast, the number of jams will grow by 20 per cent over the next ten years. Nearly a quarter of British people find themselves in a jam every day and 55 per cent at least once a week.

**V.** Nowadays many British people take their children to school by car. Twenty years ago, nearly one in three primary school children made their own way to school. Now only one child in nine makes their own way. During the school year at 08:50 a.m. one car in five on the roads in any British town is taking children to school. The solution could be special school buses widely used in the USA.

**VI.** Many scientists hope that new technologies allowing more people to work at home may help with traffic problems. Fewer people will work from 9 to 5 and travel to and from work during the rush hour. But only 15% of people now want to spend more time working at home. The workplace is, for many people, a place to meet other people and to talk to them, so they would miss it if they worked from home.`,
        matchOptions: [
          "A – Bicycle is faster",
          "B – Controlling skies",
          "C – Office at home",
          "D – Lack of safety",
          "E – Paid roads",
          "F – Improving railways",
          "G – Blocked roads",
          "H – Buses instead of cars",
        ],
        questions: [
          {
            id: "r3q15",
            number: 15,
            type: "matching-dropdown",
            prompt: "Paragraph I",
          },
          {
            id: "r3q16",
            number: 16,
            type: "matching-dropdown",
            prompt: "Paragraph II",
          },
          {
            id: "r3q17",
            number: 17,
            type: "matching-dropdown",
            prompt: "Paragraph III",
          },
          {
            id: "r3q18",
            number: 18,
            type: "matching-dropdown",
            prompt: "Paragraph IV",
          },
          {
            id: "r3q19",
            number: 19,
            type: "matching-dropdown",
            prompt: "Paragraph V",
          },
          {
            id: "r3q20",
            number: 20,
            type: "matching-dropdown",
            prompt: "Paragraph VI",
          },
        ],
      },
      {
        id: "reading-4",
        title: "Part 4",
        range: "21–29",
        instructions:
          "Read the text and answer questions 21–29. For questions 21–24, choose the correct answer (A, B, C, or D). For questions 25–29, choose True, False, or No information.",
        text: `Alan McCormick, 16, lives near Sacramento, California, and has been learning Chinese for two years.

"The lessons are interesting because our teacher explains to us what the characters mean and how they become what they are. Sometimes we also watch Chinese movies. The hardest thing is to write characters and listen to other people speak Mandarin."

California has had close ties to China for many years. Since many immigrants came from China originally, the Chinese language has often been passed on by family members. What is interesting is that in the last few years, kids like Alan, who have no direct ties to China, are learning Mandarin a lot earlier and in greater numbers. Currently, more than 100 schools in California are offering Mandarin classes.

Spanish has always been the second most important language in many parts of the USA, although German and French are also old favorites. That Mandarin, a much more exotic language, is able to penetrate this standing is due largely to China's increased global presence.

Officially, there are more than 80,000 nationals from the People's Republic of China in America, including 27,000 students. But many more ethnic Chinese from all over the world live here too. Not surprisingly, interest in all things Chinese has grown – food, art, fengshui, acupuncture, gongfu, sports. Bruce Lee and Jackie Chan have always held an audience, but now, so do Ang Lee and Zhang Yimou. Chinese film festivals, concerts, and even Chinese disco nights draw American audiences too.

But it is not easy teaching American kids Mandarin. Many lower secondary schools offer the language as an after school activity much as football or music club is offered. So students come from different classes and ages and tend not to meet one another daily. There is also little support at home, unlike Chinese or Chinese-American children who usually attend Chinese schools run by Chinese organizations, and which follow a mainland or Taiwanese curriculum.

"We all found that after a little while, Chinese classes for American kids slowed down and language learners became demotivated by the increasing number of complicated characters. They needed a very long time to learn simple questions and answers. Students could not express what they really wanted to express. And, after learning so much, they still could not read interesting stuff," says Lu Wing, a teacher, interpreter and textbook author.

The problems are compounded by the lack of staff and of appropriate teaching material. Many schools employ a native Chinese national who may or may not be qualified, and they are not paid very well.

The Association of Chinese Teachers in America has organized workshops and seminars to exchange ideas and resources. But the training and certification of teachers will continue to be difficult as there is no central authority.

Student numbers need to increase significantly before the various state ministries of education will get involved seriously, and students can only be attracted if good teachers exist in the first place.

Wing has written a textbook which has become the official learning material for Chinese at upper secondary levels in some states. "I separated the learning of characters from the training of dialogues. This strategy allowed the students to start character learning a bit more systematically, which in itself enhances the possibilities of character training – more characters are remembered in shorter time. On the other hand, without the burden of needing to read and write every single character in a dialogue text, the students were able to get on to more interesting subjects of discussion much earlier than before."

Wing stresses that young learners need to learn in a fun, interactive way and encourages the use of theatre, songs, games, films, competitions, picture shows and presentations for parents and other students. "And, of course having the possibility to travel to China is one of the most attractive aims for learning the language." When asked about his opinion, Alan responded that he would like to go to China one day, but only for vacations.

The future of Mandarin in Californian schools seems bright. Some schools in various states have incorporated Mandarin into the school curriculum and are offering it as a pre-university subject.`,
        questions: [
          {
            id: "r4q21",
            number: 21,
            type: "mcq",
            prompt: "American students like Alan McCormick",
            options: [
              {
                label: "A",
                text: "are becoming more interested in attending Mandarin classes.",
              },
              {
                label: "B",
                text: "think it's easy to learn to write Chinese characters.",
              },
              { label: "C", text: "will work as translators when they leave school." },
              { label: "D", text: "wish Mandarin to be a global language." },
            ],
          },
          {
            id: "r4q22",
            number: 22,
            type: "mcq",
            prompt: "A large number of Chinese people in America",
            options: [
              {
                label: "A",
                text: "are causing Mandarin to become the most taught foreign language in school.",
              },
              {
                label: "B",
                text: "are creating more interest in the Chinese culture as a whole.",
              },
              { label: "C", text: "are more interested in learning German or French." },
              { label: "D", text: "are starting to learn Spanish." },
            ],
          },
          {
            id: "r4q23",
            number: 23,
            type: "mcq",
            prompt: "American kids learning Mandarin",
            options: [
              {
                label: "A",
                text: "are often not able to get beyond the beginner level.",
              },
              { label: "B", text: "get a lot of encouragement from their parents." },
              {
                label: "C",
                text: "need to learn according to the curriculum of schools in China or Taiwan.",
              },
              { label: "D", text: "love cartoons in Mandarin." },
            ],
          },
          {
            id: "r4q24",
            number: 24,
            type: "mcq",
            prompt: "Mandarin teachers in America are",
            options: [
              {
                label: "A",
                text: "certified by the Ministry of Education in the state where they live.",
              },
              {
                label: "B",
                text: "challenged by the lack of suitable textbooks and resources.",
              },
              { label: "C", text: "generally trained teachers who came from China." },
              { label: "D", text: "all graduated from universities in China." },
            ],
          },
          {
            id: "r4q25",
            number: 25,
            type: "mcq",
            prompt:
              "All Chinese language speakers in California learn Chinese from their relatives at home.",
            options: [
              { label: "A", text: "True" },
              { label: "B", text: "False" },
              { label: "C", text: "No information" },
            ],
          },
          {
            id: "r4q26",
            number: 26,
            type: "mcq",
            prompt:
              "Chinese is becoming one of the most popular languages in the US as the number of Chinese people and the influence of China are rising there.",
            options: [
              { label: "A", text: "True" },
              { label: "B", text: "False" },
              { label: "C", text: "No information" },
            ],
          },
          {
            id: "r4q27",
            number: 27,
            type: "mcq",
            prompt:
              "All the native speaker teachers who teach Chinese in the US have sufficient qualifications in their role.",
            options: [
              { label: "A", text: "True" },
              { label: "B", text: "False" },
              { label: "C", text: "No information" },
            ],
          },
          {
            id: "r4q28",
            number: 28,
            type: "mcq",
            prompt:
              "In Wing's teaching textbooks, the characters are taught much later in lessons than the dialogues.",
            options: [
              { label: "A", text: "True" },
              { label: "B", text: "False" },
              { label: "C", text: "No information" },
            ],
          },
          {
            id: "r4q29",
            number: 29,
            type: "mcq",
            prompt:
              "Currently, the students are learning Chinese only at elementary levels in the US.",
            options: [
              { label: "A", text: "True" },
              { label: "B", text: "False" },
              { label: "C", text: "No information" },
            ],
          },
        ],
      },
      {
        id: "reading-5",
        title: "Part 5",
        range: "30–35",
        instructions:
          "Read the text and answer questions 30–33 (gap-fill) and 34–35 (multiple choice).",
        text: `**Hyperpolyglots – A case of brainpower or hard work?**

In 1996, DICK HUDSON, a professor of linguistics at University College London, posted an email to a list serve for language scientists asking if anyone knew who held the world record for the number of languages they could speak. Replies listed the names of well-known polyglots, such as Giuseppe Mezzofanti, an eighteenth-century Italian cardinal.

Then, in 2003, Hudson received an unexpected reply to his email from someone who had belatedly come across his question. The writer, 'N', described how his grandfather, who was Sicilian and had never gone to school, could learn languages with such remarkable ease that by the end of his life he could speak seventy, and read and write fifty-six. N's grandfather was twenty when he moved to New York in the early 1900s. There he worked on the railways, which brought him into contact with travelers speaking many languages. When N was ten, he accompanied his grandfather on a cruise which took them to over 20 countries, from Venezuela to Hong Kong and Japan. N claimed that whatever port they visited, his grandfather knew the local language.

When Hudson read N's note, he immediately recognized the potential significance of the claims and posted them on the Internet. In his posting, he coined the term 'hyperpolyglot', which he defined as someone who speaks six languages or more.

Until recently, there was little scientific information about hyperpolyglots. Mezzofanti, for example, was supposed to have known seventy-two languages and to have spoken thirty-nine fluently, but nowadays such tales are often greeted with skepticism.

Philip Herdina, at the University of Innsbruck in Austria, is a skeptic. He doubts whether anyone has the capacity to speak seventy-two languages, arguing that maintaining this ability would take resources from other activities.

But if ability to learn many languages is the norm, why are so few people able to exploit it? Stephen Krashen, from the University of California, maintains that exceptional language learners simply work harder, and have a better understanding of how they learn. Krashen cites the case of Lomb Kato, an eighty-six-year-old Hungarian interpreter who could speak sixteen languages. Lomb apparently felt she had no special talent for languages; she had taken classes in Chinese and Polish, but the others she taught herself.

Other researchers say that exceptional brains play a more significant role. In the 1980s, neurolinguist Loraine Obler of the City University of New York found a talented language learner she called 'CJ', who could speak five languages. CJ had learned to read late, had an average IQ, and had always been a mediocre student. However, on the Modern Language Aptitude Test, he scored extremely high. His verbal memory was very good, he could remember lists of words for weeks, but he quickly forgot images and numbers, and had problems reading maps. All of this seemed to indicate that CJ's language talent was inborn and not related to a higher level of general intellectual ability.`,
        questions: [
          {
            id: "r5q30",
            number: 30,
            type: "gap-fill",
            prompt: "N came from a family which was partly of ___ origin.",
            placeholder: "word...",
          },
          {
            id: "r5q31",
            number: 31,
            type: "gap-fill",
            prompt: "The first relative was N's ___",
            placeholder: "word...",
          },
          {
            id: "r5q32",
            number: 32,
            type: "gap-fill",
            prompt: "… who was said to speak ___ languages.",
            placeholder: "number...",
          },
          {
            id: "r5q33",
            number: 33,
            type: "gap-fill",
            prompt: "N witnessed this ability during a tour of more than ___",
            placeholder: "answer...",
          },
          {
            id: "r5q34",
            number: 34,
            type: "mcq",
            prompt:
              "Who thinks that successful language learning requires motivation, application, and a learning strategy?",
            options: [
              { label: "A", text: "Loraine Obler" },
              { label: "B", text: "Stephen Krashen" },
              { label: "C", text: "Mezzofanti" },
              { label: "D", text: "Philip Herdina" },
            ],
          },
          {
            id: "r5q35",
            number: 35,
            type: "mcq",
            prompt: "Language aptitude is probably inherited, not a facet of intelligence.",
            options: [
              { label: "A", text: "Loraine Obler" },
              { label: "B", text: "Stephen Krashen" },
              { label: "C", text: "Mezzofanti" },
              { label: "D", text: "Philip Herdina" },
            ],
          },
        ],
      },
    ],
  },
  {
    id: "writing",
    title: "Writing",
    duration: 60,
    parts: [
      {
        id: "writing-1",
        title: "Task 1.1",
        range: "Email to a friend",
        instructions: "Write a short email to your friend who is also in the club. Say what type of volunteering you'd like to do and why you think it's important. Write about 50 words.",
        context: `**Context**

You are a member of a youth volunteering club. You received an email from the club coordinator.

**Email**

Dear Member,

We are planning our next volunteering project and would like to hear your ideas. What kind of volunteering activity do you think would be most helpful for the community? Who should take part in it and why? How can we encourage more young people to join the club? Your suggestions will help us organize a meaningful and successful project.

Best regards,
Volunteering Club Coordinator`,
        questions: [
          {
            id: "w1q1",
            number: 1,
            type: "textarea",
            prompt: "Your response",
            wordLimit: "45–60 words",
            placeholder:
              "Write your email here...",
          },
        ],
      },
      {
        id: "writing-2",
        title: "Task 1.2",
        range: "Email to the coordinator",
        instructions:
          "Write an email to the club coordinator. Share your opinion about what kind of volunteering project would be the most useful. Explain who should join, how it can help the community, and suggest ways to encourage participation. Write 120–150 words.",
        context: `**Context**

You are a member of a youth volunteering club. You received an email from the club coordinator.

**Email**

Dear Member,

We are planning our next volunteering project and would like to hear your ideas. What kind of volunteering activity do you think would be most helpful for the community? Who should take part in it and why? How can we encourage more young people to join the club? Your suggestions will help us organize a meaningful and successful project.

Best regards,
Volunteering Club Coordinator`,
        questions: [
          {
            id: "w2q1",
            number: 1,
            type: "textarea",
            prompt: "Your response",
            wordLimit: "120–150 words",
            placeholder:
              "Write your email here...",
          },
        ],
      },
      {
        id: "writing-3",
        title: "Task 2",
        range: "Online discussion post",
        instructions:
          "Post your response to the online discussion, giving reasons and examples. Write 180–200 words.",
        context: `**Context**

You are participating in an online discussion for language learners.

**The question is:**

Some people believe modern technology makes us more connected than ever, while others argue that it is causing people to become more isolated.

What is your opinion?`,
        questions: [
          {
            id: "w3q1",
            number: 1,
            type: "textarea",
            prompt: "Your response",
            wordLimit: "180–200 words",
            placeholder:
              "Write your discussion post here...",
          },
        ],
      },
    ],
  },
];
